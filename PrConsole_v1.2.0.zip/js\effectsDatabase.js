/**
 * Comprehensive Database of Premiere Pro Effects, Transitions, Audio Filters, Commands, and Labels
 * Includes 150+ native items covering all major categories with high-accuracy matchNames
 */

var EFFECTS_DATABASE = typeof window !== 'undefined' && window.EFFECTS_DATABASE ? window.EFFECTS_DATABASE : [

    // ==========================================
    // 1. VIDEO EFFECTS: COLOR & LUMETRI
    // ==========================================
    {
        id: "lumetri_color",
        favorite: false,
        name: "Lumetri Color",
        category: "Color Correction",
        type: "video_effect",
        icon: "palette",
        matchName: "Lumetri",
        description: "Professional color grading, curves, HSL secondary, and LUT application.",
        keywords: ["color", "grade", "lut", "lum", "curves", "saturation", "exposure", "white balance", "contrast"]
    },
    {
        id: "tint",
        favorite: false,
        name: "Tint",
        category: "Color Correction",
        type: "video_effect",
        icon: "sun",
        matchName: "Tint",
        description: "Map black and white values to custom colors for duotones.",
        keywords: ["tint", "duotone", "monochrome", "color map", "black and white"]
    },
    {
        id: "black_and_white",
        favorite: false,
        name: "Black & White",
        category: "Color Correction",
        type: "video_effect",
        icon: "moon",
        matchName: "Black & White",
        description: "Instant high-contrast monochrome conversion.",
        keywords: ["bw", "black white", "grayscale", "desaturate", "mono"]
    },
    {
        id: "brightness_contrast",
        favorite: false,
        name: "Brightness & Contrast",
        category: "Color Correction",
        type: "video_effect",
        icon: "sun",
        matchName: "Brightness & Contrast",
        description: "Simple brightness and tonal contrast adjustment.",
        keywords: ["brightness", "contrast", "light", "dark", "exposure"]
    },
    {
        id: "color_balance",
        favorite: false,
        name: "Color Balance",
        category: "Color Correction",
        type: "video_effect",
        icon: "sliders",
        matchName: "Color Balance",
        description: "Shadow, Midtone, and Highlight RGB channel balance.",
        keywords: ["color balance", "rgb", "shadows", "highlights", "midtones"]
    },
    {
        id: "color_balance_hls",
        favorite: false,
        name: "Color Balance (HLS)",
        category: "Color Correction",
        type: "video_effect",
        icon: "sliders",
        matchName: "Color Balance (HLS)",
        description: "Hue, Lightness, and Saturation adjustments.",
        keywords: ["hls", "hue", "saturation", "lightness", "color"]
    },
    {
        id: "leave_color",
        favorite: false,
        name: "Leave Color",
        category: "Color Correction",
        type: "video_effect",
        icon: "eye",
        matchName: "Leave Color",
        description: "Isolate a single color while desaturating everything else.",
        keywords: ["leave color", "isolate", "sin city", "selective color"]
    },
    {
        id: "video_limiter",
        favorite: false,
        name: "Video Limiter",
        category: "Color Correction",
        type: "video_effect",
        icon: "shield",
        matchName: "Video Limiter",
        description: "Broadcast-safe IRE chroma and luma level clamping.",
        keywords: ["limiter", "broadcast safe", "ire", "clipping", "legal"]
    },
    {
        id: "equalize",
        favorite: false,
        name: "Equalize",
        category: "Color Correction",
        type: "video_effect",
        icon: "activity",
        matchName: "Equalize",
        description: "Even out histogram distribution across the entire frame.",
        keywords: ["equalize", "histogram", "auto levels"]
    },
    {
        id: "asc_cdl",
        favorite: false,
        name: "ASC CDL",
        category: "Color Correction",
        type: "video_effect",
        icon: "sliders",
        matchName: "ASC CDL",
        description: "Slope, Offset, Power, and Saturation industry standard color grading.",
        keywords: ["cdl", "slope", "offset", "power", "sat"]
    },

    // ==========================================
    // 2. VIDEO EFFECTS: BLUR & SHARPEN
    // ==========================================
    {
        id: "gaussian_blur",
        favorite: false,
        name: "Gaussian Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "droplet",
        matchName: "Gaussian Blur",
        description: "Smooth bell-curve blur with repeatable edge pixels control.",
        keywords: ["blur", "gauss", "soften", "bokeh", "defocus", "background blur"]
    },
    {
        id: "directional_blur",
        favorite: false,
        name: "Directional Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "wind",
        matchName: "Directional Blur",
        description: "Linear blur along an adjustable angle for speed simulation.",
        keywords: ["dir blur", "motion blur", "linear blur", "angle blur", "speed", "fast"]
    },
    {
        id: "sharpen",
        favorite: false,
        name: "Sharpen",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "zap",
        matchName: "Sharpen",
        description: "Enhance high-frequency edge contrast and clarity.",
        keywords: ["sharp", "crisp", "detail", "clarity", "enhance"]
    },
    {
        id: "unsharp_mask",
        favorite: false,
        name: "Unsharp Mask",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "zap",
        matchName: "Unsharp Mask",
        description: "Fine-tune edge sharpening with Radius, Amount, and Threshold.",
        keywords: ["unsharp", "mask", "sharp", "clarity", "detail"]
    },
    {
        id: "radial_blur",
        favorite: false,
        name: "Radial Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "rotate-cw",
        matchName: "Radial Blur",
        description: "Spin or Zoom circular motion blur centered on a focal point.",
        keywords: ["radial", "spin", "zoom blur", "circle", "impact"]
    },
    {
        id: "camera_blur",
        favorite: false,
        name: "Camera Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "camera",
        matchName: "Camera Blur",
        description: "Simulate physical optical lens aperture defocus.",
        keywords: ["camera blur", "defocus", "iris", "bokeh", "aperture"]
    },
    {
        id: "channel_blur",
        favorite: false,
        name: "Channel Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "droplet",
        matchName: "Channel Blur",
        description: "Blur Red, Green, Blue, or Alpha channels independently.",
        keywords: ["channel blur", "rgb blur", "chromatic", "alpha blur"]
    },
    {
        id: "compound_blur",
        favorite: false,
        name: "Compound Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "layers",
        matchName: "Compound Blur",
        description: "Blur pixels based on the luminance map of another layer.",
        keywords: ["compound blur", "matte blur", "depth map"]
    },
    {
        id: "fast_blur",
        favorite: false,
        name: "Fast Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "droplet",
        matchName: "Fast Blur",
        description: "Lightweight fast-rendering box blur.",
        keywords: ["fast blur", "quick blur", "box blur"]
    },

    // ==========================================
    // 3. VIDEO EFFECTS: DISTORT & TRANSFORM
    // ==========================================
    {
        id: "crop",
        favorite: false,
        name: "Crop",
        category: "Transform",
        type: "video_effect",
        icon: "crop",
        matchName: "Crop",
        description: "Trim Left, Top, Right, and Bottom edges with edge feathering.",
        keywords: ["crop", "trim", "split", "letterbox", "aspect", "frame", "widescreen"]
    },
    {
        id: "transform",
        favorite: false,
        name: "Transform",
        category: "Distort",
        type: "video_effect",
        icon: "move",
        matchName: "Transform",
        description: "Position, Scale, Rotation, and custom Shutter Angle motion blur.",
        keywords: ["transform", "scale", "position", "shutter angle", "motion blur", "zoom", "whip"]
    },
    {
        id: "warp_stabilizer",
        favorite: false,
        name: "Warp Stabilizer",
        category: "Distort",
        type: "video_effect",
        icon: "shield",
        matchName: "Warp Stabilizer",
        description: "Analyze and smooth handheld camera shakiness automatically.",
        keywords: ["warp", "stabilize", "smooth", "shake", "camera", "motion", "steady", "tracking"]
    },
    {
        id: "lens_distortion",
        favorite: false,
        name: "Lens Distortion",
        category: "Distort",
        type: "video_effect",
        icon: "eye",
        matchName: "Lens Distortion",
        description: "Fisheye curvature or barrel/pincushion optical correction.",
        keywords: ["lens", "fisheye", "curvature", "distort", "gopro", "barrel", "action cam"]
    },
    {
        id: "turbulent_displace",
        favorite: false,
        name: "Turbulent Displace",
        category: "Distort",
        type: "video_effect",
        icon: "activity",
        matchName: "Turbulent Displace",
        description: "Procedural fractal turbulence, heat wave, and water distortion.",
        keywords: ["glitch", "turbulent", "liquid", "warp", "wave", "displace", "organic", "heat wave"]
    },
    {
        id: "corner_pin",
        favorite: false,
        name: "Corner Pin",
        category: "Distort",
        type: "video_effect",
        icon: "maximize-2",
        matchName: "Corner Pin",
        description: "4-corner perspective stretching for screen and sign replacements.",
        keywords: ["corner pin", "perspective", "screen", "skew", "4 point", "pin"]
    },
    {
        id: "mirror",
        favorite: false,
        name: "Mirror",
        category: "Distort",
        type: "video_effect",
        icon: "columns",
        matchName: "Mirror",
        description: "Reflect frame half across an adjustable center angle plane.",
        keywords: ["mirror", "reflection", "kaleidoscope", "symmetry", "flip"]
    },
    {
        id: "spherize",
        favorite: false,
        name: "Spherize",
        category: "Distort",
        type: "video_effect",
        icon: "circle",
        matchName: "Spherize",
        description: "Wrap imagery around a 3D spherical lens dome.",
        keywords: ["sphere", "globe", "bubble", "fish eye", "3d ball"]
    },
    {
        id: "twirl",
        favorite: false,
        name: "Twirl",
        category: "Distort",
        type: "video_effect",
        icon: "rotate-cw",
        matchName: "Twirl",
        description: "Rotate and spiral pixels around a central vortex.",
        keywords: ["twirl", "spiral", "vortex", "spin", "swirl"]
    },
    {
        id: "wave_warp",
        favorite: false,
        name: "Wave Warp",
        category: "Distort",
        type: "video_effect",
        icon: "activity",
        matchName: "Wave Warp",
        description: "Sine, square, or triangle animated ripple waves.",
        keywords: ["wave", "ripple", "water", "flag", "warp"]
    },
    {
        id: "ripple",
        favorite: false,
        name: "Ripple",
        category: "Distort",
        type: "video_effect",
        icon: "radio",
        matchName: "Ripple",
        description: "Concentric circular ripples propagating outward like a water drop.",
        keywords: ["ripple", "water drop", "waves", "splash"]
    },
    {
        id: "magnify",
        favorite: false,
        name: "Magnify",
        category: "Distort",
        type: "video_effect",
        icon: "zoom-in",
        matchName: "Magnify",
        description: "Virtual magnifying glass over a portion of the screen.",
        keywords: ["magnify", "zoom", "glass", "lens", "spotlight"]
    },
    {
        id: "offset",
        favorite: false,
        name: "Offset",
        category: "Distort",
        type: "video_effect",
        icon: "refresh-cw",
        matchName: "Offset",
        description: "Shift frame X and Y with continuous seamless looping wraparound.",
        keywords: ["offset", "wrap", "pan", "seamless", "infinite scroll"]
    },
    {
        id: "polar_coordinates",
        favorite: false,
        name: "Polar Coordinates",
        category: "Distort",
        type: "video_effect",
        icon: "compass",
        matchName: "Polar Coordinates",
        description: "Convert Rectangular coordinates to Polar circle and vice versa.",
        keywords: ["polar", "tiny planet", "rect to polar", "circle"]
    },
    {
        id: "rolling_shutter_repair",
        favorite: false,
        name: "Rolling Shutter Repair",
        category: "Distort",
        type: "video_effect",
        icon: "shield",
        matchName: "Rolling Shutter Repair",
        description: "Remove CMOS sensor jello effect and vertical wobble.",
        keywords: ["shutter", "jello", "cmos", "wobble", "repair"]
    },

    // ==========================================
    // 4. VIDEO EFFECTS: KEYING & MATTE
    // ==========================================
    {
        id: "ultra_key",
        favorite: false,
        name: "Ultra Key",
        category: "Keying",
        type: "video_effect",
        icon: "sparkles",
        matchName: "Ultra Key",
        description: "Fast, pristine Green/Blue screen chroma keyer with spill suppression.",
        keywords: ["key", "green screen", "chroma", "ultra", "matte", "alpha", "blue screen"]
    },
    {
        id: "track_matte_key",
        favorite: false,
        name: "Track Matte Key",
        category: "Keying",
        type: "video_effect",
        icon: "layers",
        matchName: "Track Matte Key",
        description: "Use another video track's alpha or luminance as a dynamic mask cutout.",
        keywords: ["track matte", "mask", "matte", "alpha matte", "luma matte", "cutout"]
    },
    {
        id: "color_key",
        favorite: false,
        name: "Color Key",
        category: "Keying",
        type: "video_effect",
        icon: "droplet",
        matchName: "Color Key",
        description: "Target a specific RGB color value to make transparent.",
        keywords: ["color key", "chroma", "solid key", "eyedropper"]
    },
    {
        id: "luma_key",
        favorite: false,
        name: "Luma Key",
        category: "Keying",
        type: "video_effect",
        icon: "sun",
        matchName: "Luma Key",
        description: "Key out pixels based on brightness/luminance threshold.",
        keywords: ["luma", "luminance", "dark key", "light key", "black background"]
    },
    {
        id: "difference_matte",
        favorite: false,
        name: "Difference Matte",
        category: "Keying",
        type: "video_effect",
        icon: "layers",
        matchName: "Difference Matte",
        description: "Compare footage with a background plate and isolate differences.",
        keywords: ["difference matte", "clean plate", "isolate"]
    },

    // ==========================================
    // 5. VIDEO EFFECTS: PERSPECTIVE
    // ==========================================
    {
        id: "drop_shadow",
        favorite: false,
        name: "Drop Shadow",
        category: "Perspective",
        type: "video_effect",
        icon: "layers",
        matchName: "Drop Shadow",
        description: "Add soft or sharp directional depth shadow to titles and graphics.",
        keywords: ["shadow", "drop", "depth", "elevation", "3d", "subtitle"]
    },
    {
        id: "radial_shadow",
        favorite: false,
        name: "Radial Shadow",
        category: "Perspective",
        type: "video_effect",
        icon: "sun",
        matchName: "Radial Shadow",
        description: "Cast cast-shadows radially away from a designated light source point.",
        keywords: ["radial shadow", "light source", "cast shadow", "sun shadow"]
    },
    {
        id: "basic_3d",
        favorite: false,
        name: "Basic 3D",
        category: "Perspective",
        type: "video_effect",
        icon: "box",
        matchName: "Basic 3D",
        description: "Swivel, Tilt, and Distance to Image in virtual 3D space.",
        keywords: ["3d", "swivel", "tilt", "perspective", "rotate 3d", "card flip"]
    },
    {
        id: "bevel_alpha",
        favorite: false,
        name: "Bevel Alpha",
        category: "Perspective",
        type: "video_effect",
        icon: "square",
        matchName: "Bevel Alpha",
        description: "Give graphic and text edges a chiseled 3D beveled look.",
        keywords: ["bevel", "emboss", "chiseled", "3d edge"]
    },

    // ==========================================
    // 6. VIDEO EFFECTS: STYLIZE
    // ==========================================
    {
        id: "mosaic",
        favorite: false,
        name: "Mosaic",
        category: "Stylize",
        type: "video_effect",
        icon: "grid",
        matchName: "Mosaic",
        description: "Pixelate areas into grid blocks for censorship or 8-bit retro vibes.",
        keywords: ["pixel", "mosaic", "censor", "blur face", "blocks", "8bit", "retro"]
    },
    {
        id: "find_edges",
        favorite: false,
        name: "Find Edges",
        category: "Stylize",
        type: "video_effect",
        icon: "edit-3",
        matchName: "Find Edges",
        description: "Identify high-contrast boundaries to create an outline sketch look.",
        keywords: ["sketch", "outline", "edges", "neon lines", "pencil"]
    },
    {
        id: "strobe_light",
        favorite: false,
        name: "Strobe Light",
        category: "Stylize",
        type: "video_effect",
        icon: "zap",
        matchName: "Strobe Light",
        description: "Periodic flash bursts or periodic transparency strobe.",
        keywords: ["strobe", "flash", "flicker", "lightning", "rave"]
    },
    {
        id: "posterize",
        favorite: false,
        name: "Posterize",
        category: "Stylize",
        type: "video_effect",
        icon: "layers",
        matchName: "Posterize",
        description: "Quantize colors to a limited palette for a screen-printed poster look.",
        keywords: ["posterize", "flat color", "pop art", "limited palette"]
    },
    {
        id: "threshold",
        favorite: false,
        name: "Threshold",
        category: "Stylize",
        type: "video_effect",
        icon: "sliders",
        matchName: "Threshold",
        description: "Convert image strictly to black or white based on luminance threshold.",
        keywords: ["threshold", "binary", "high contrast", "stencil"]
    },
    {
        id: "solarize",
        favorite: false,
        name: "Solarize",
        category: "Stylize",
        type: "video_effect",
        icon: "sun",
        matchName: "Solarize",
        description: "Invert tones above a certain threshold like film solarization.",
        keywords: ["solarize", "psychedelic", "invert tones"]
    },
    {
        id: "roughen_edges",
        favorite: false,
        name: "Roughen Edges",
        category: "Stylize",
        type: "video_effect",
        icon: "scissors",
        matchName: "Roughen Edges",
        description: "Roughen and corrode edges for paper tear, watercolor, or grunge looks.",
        keywords: ["roughen", "paper tear", "grunge", "torn edge", "watercolor"]
    },

    // ==========================================
    // 7. VIDEO EFFECTS: GENERATE
    // ==========================================
    {
        id: "ramp",
        favorite: false,
        name: "Gradient Ramp",
        category: "Generate",
        type: "video_effect",
        icon: "droplet",
        matchName: "Ramp",
        description: "Linear or Radial 2-color smooth color gradient backdrop.",
        keywords: ["ramp", "gradient", "linear ramp", "radial ramp", "background"]
    },
    {
        id: "four_color_gradient",
        favorite: false,
        name: "4-Color Gradient",
        category: "Generate",
        type: "video_effect",
        icon: "palette",
        matchName: "4-Color Gradient",
        description: "Rich blended 4-point mesh color background.",
        keywords: ["gradient", "4 color", "mesh", "colorful", "blend"]
    },
    {
        id: "lens_flare",
        favorite: false,
        name: "Lens Flare",
        category: "Generate",
        type: "video_effect",
        icon: "sun",
        matchName: "Lens Flare",
        description: "Cinematic optical sunburst and anamorphic lens rings.",
        keywords: ["flare", "lens flare", "sun", "anamorphic", "optics", "glare"]
    },
    {
        id: "grid",
        favorite: false,
        name: "Grid",
        category: "Generate",
        type: "video_effect",
        icon: "grid",
        matchName: "Grid",
        description: "Configurable geometric grid lines or blueprint overlays.",
        keywords: ["grid", "lines", "blueprint", "mesh", "matrix"]
    },
    {
        id: "cell_pattern",
        favorite: false,
        name: "Cell Pattern",
        category: "Generate",
        type: "video_effect",
        icon: "hash",
        matchName: "Cell Pattern",
        description: "Procedural organic cells, crystals, and tile textures.",
        keywords: ["cells", "organic", "crystallize", "texture", "pattern"]
    },
    {
        id: "lightning",
        favorite: false,
        name: "Lightning",
        category: "Generate",
        type: "video_effect",
        icon: "zap",
        matchName: "Lightning",
        description: "Procedural electric arc lightning bolt generator.",
        keywords: ["lightning", "electricity", "spark", "bolt", "plasma"]
    },

    // ==========================================
    // 8. VIDEO EFFECTS: NOISE, CHANNEL & TIME
    // ==========================================
    {
        id: "noise",
        favorite: false,
        name: "Noise",
        category: "Noise & Grain",
        type: "video_effect",
        icon: "film",
        matchName: "Noise",
        description: "Add subtle film grain or analog television noise texture.",
        keywords: ["grain", "noise", "film grain", "texture", "analog", "iso"]
    },
    {
        id: "median",
        favorite: false,
        name: "Median",
        category: "Noise & Grain",
        type: "video_effect",
        icon: "filter",
        matchName: "Median",
        description: "Smooth out speckled digital noise and pixel blemishes.",
        keywords: ["median", "denoise", "smooth", "blemish", "skin clean"]
    },
    {
        id: "dust_and_scratches",
        favorite: false,
        name: "Dust & Scratches",
        category: "Noise & Grain",
        type: "video_effect",
        icon: "disc",
        matchName: "Dust & Scratches",
        description: "Eliminate film scratches, sensor dust specks, and artifacts.",
        keywords: ["dust", "scratches", "film restoration", "spot remove"]
    },
    {
        id: "invert",
        favorite: false,
        name: "Invert",
        category: "Channel",
        type: "video_effect",
        icon: "refresh-cw",
        matchName: "Invert",
        description: "Invert RGB colors or individual color/alpha channels.",
        keywords: ["invert", "negative", "opposite", "xray", "film negative"]
    },
    {
        id: "posterize_time",
        favorite: false,
        name: "Posterize Time",
        category: "Time",
        type: "video_effect",
        icon: "clock",
        matchName: "Posterize Time",
        description: "Lock playback to an intentional lower frame rate (e.g., 12fps anime look).",
        keywords: ["fps", "stop motion", "anime", "frame rate", "stutter", "retro", "12fps"]
    },
    {
        id: "echo",
        favorite: false,
        name: "Echo",
        category: "Time",
        type: "video_effect",
        icon: "copy",
        matchName: "Echo",
        description: "Ghost trailing frame repetitions for motion trails.",
        keywords: ["echo", "ghost", "trails", "motion trail", "afterimage"]
    },

    // ==========================================
    // 9. VIDEO TRANSITIONS
    // ==========================================
    {
        id: "cross_dissolve",
        favorite: false,
        name: "Cross Dissolve",
        category: "Video Transitions",
        type: "transition",
        icon: "maximize-2",
        matchName: "Cross Dissolve",
        description: "Standard smooth blend transition between two adjacent clips.",
        keywords: ["dissolve", "fade", "transition", "cross dissolve", "smooth blend"]
    },
    {
        id: "dip_to_black",
        favorite: false,
        name: "Dip to Black",
        category: "Video Transitions",
        type: "transition",
        icon: "moon",
        matchName: "Dip to Black",
        description: "Fade out into pure black, then fade in to next scene.",
        keywords: ["dip to black", "fade out", "black fade", "scene cut"]
    },
    {
        id: "dip_to_white",
        favorite: false,
        name: "Dip to White",
        category: "Video Transitions",
        type: "transition",
        icon: "sun",
        matchName: "Dip to White",
        description: "Flash transition fading through pure white exposure burst.",
        keywords: ["dip to white", "flash", "white flash", "burst"]
    },
    {
        id: "film_dissolve",
        favorite: false,
        name: "Film Dissolve",
        category: "Video Transitions",
        type: "transition",
        icon: "film",
        matchName: "Film Dissolve",
        description: "Optical photographic film print cross dissolve curve.",
        keywords: ["film dissolve", "film fade", "cinematic dissolve"]
    },
    {
        id: "morph_cut",
        favorite: false,
        name: "Morph Cut",
        category: "Video Transitions",
        type: "transition",
        icon: "git-commit",
        matchName: "Morph Cut",
        description: "Seamlessly conceal jump cuts in talking head interviews.",
        keywords: ["morph cut", "jump cut", "seamless", "talking head", "interview"]
    },
    {
        id: "push",
        favorite: false,
        name: "Push",
        category: "Video Transitions",
        type: "transition",
        icon: "arrow-right",
        matchName: "Push",
        description: "Incoming clip pushes the outgoing clip off screen.",
        keywords: ["push", "slide", "wipe", "directional push"]
    },
    {
        id: "slide",
        favorite: false,
        name: "Slide",
        category: "Video Transitions",
        type: "transition",
        icon: "arrow-up-right",
        matchName: "Slide",
        description: "Incoming clip slides across over top of the outgoing clip.",
        keywords: ["slide", "glide", "smooth slide"]
    },
    {
        id: "zoom_transition",
        favorite: false,
        name: "Cross Zoom",
        category: "Video Transitions",
        type: "transition",
        icon: "zoom-in",
        matchName: "Cross Zoom",
        description: "Fast dynamic whip-zoom in and out transition.",
        keywords: ["zoom", "cross zoom", "whip zoom", "impact"]
    },
    {
        id: "radial_wipe",
        favorite: false,
        name: "Radial Wipe",
        category: "Video Transitions",
        type: "transition",
        icon: "pie-chart",
        matchName: "Radial Wipe",
        description: "Clock hand sweep wipe revealing the next video frame.",
        keywords: ["clock wipe", "radial wipe", "sweep", "reveal"]
    },

    // ==========================================
    // 10. AUDIO EFFECTS
    // ==========================================
    {
        id: "parametric_eq",
        favorite: false,
        name: "Parametric Equalizer",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "sliders",
        matchName: "Parametric Equalizer",
        description: "Multiband precision audio frequency tone shaping and sculpting.",
        keywords: ["eq", "equalizer", "audio", "bass", "treble", "frequencies", "voice"]
    },
    {
        id: "denoise",
        favorite: false,
        name: "DeNoise",
        category: "Audio Restoration",
        type: "audio_effect",
        icon: "mic-off",
        matchName: "DeNoise",
        description: "Automatic background hiss, room tone, and air conditioner hum suppression.",
        keywords: ["denoise", "noise reduction", "clean audio", "hiss", "mic clean", "room tone"]
    },
    {
        id: "dereverb",
        favorite: false,
        name: "DeReverb",
        category: "Audio Restoration",
        type: "audio_effect",
        icon: "volume-x",
        matchName: "DeReverb",
        description: "Remove hollow room echo and reverberation from dialogue.",
        keywords: ["dereverb", "echo remove", "room echo", "dry voice"]
    },
    {
        id: "multiband_compressor",
        favorite: false,
        name: "Multiband Compressor",
        category: "Amplitude & Compression",
        type: "audio_effect",
        icon: "bar-chart-2",
        matchName: "Multiband Compressor",
        description: "Even out loudness and create broadcast-ready punchy master vocals.",
        keywords: ["compressor", "loudness", "vocal punch", "broadcast", "leveler"]
    },
    {
        id: "hard_limiter",
        favorite: false,
        name: "Hard Limiter",
        category: "Amplitude & Compression",
        type: "audio_effect",
        icon: "alert-triangle",
        matchName: "Hard Limiter",
        description: "Prevent audio clipping distortion by locking the peak dB ceiling.",
        keywords: ["limiter", "ceiling", "clipping", "no peak", "audio protect", "max volume"]
    },
    {
        id: "vocal_enhancer",
        favorite: false,
        name: "Vocal Enhancer",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "mic",
        matchName: "Vocal Enhancer",
        description: "Quick tailored optimization for Male, Female, or Music vocals.",
        keywords: ["vocal", "speech", "dialogue", "clarity", "enhancer"]
    },
    {
        id: "pitch_shifter",
        favorite: false,
        name: "Pitch Shifter",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "music",
        matchName: "Pitch Shifter",
        description: "Shift pitch up or down in semitones without altering speed.",
        keywords: ["pitch", "tune", "voice changer", "deep voice", "chipmunk"]
    },
    {
        id: "studio_reverb",
        favorite: false,
        name: "Studio Reverb",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "volume-2",
        matchName: "Studio Reverb",
        description: "Add acoustic room presence, hall ambiance, or spacious reverb.",
        keywords: ["reverb", "hall", "room", "ambiance", "spacious"]
    },
    {
        id: "analog_delay",
        favorite: false,
        name: "Analog Delay",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "clock",
        matchName: "Analog Delay",
        description: "Vintage tape-style rhythmic echoes with warm harmonic saturation.",
        keywords: ["delay", "echo", "tape delay", "repeat"]
    },
    {
        id: "graphic_eq_10",
        favorite: false,
        name: "Graphic Equalizer (10 Bands)",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "sliders",
        matchName: "Graphic Equalizer (10 Bands)",
        description: "Standard 10-band slider equalizer for quick frequency balancing.",
        keywords: ["graphic eq", "10 bands", "sliders", "bass", "treble"]
    },
    {
        id: "de_hummer",
        favorite: false,
        name: "DeHummer",
        category: "Audio Restoration",
        type: "audio_effect",
        icon: "zap-off",
        matchName: "DeHummer",
        description: "Notch out 50Hz or 60Hz power line electrical hum.",
        keywords: ["dehum", "hum", "60hz", "50hz", "buzz"]
    },
    {
        id: "de_esser",
        favorite: false,
        name: "DeEsser",
        category: "Audio Restoration",
        type: "audio_effect",
        icon: "mic",
        matchName: "DeEsser",
        description: "Attenuate harsh 'S' and 'T' sibilance in dialogue tracks.",
        keywords: ["deesser", "sibilance", "harsh", "treble harsh"]
    },

    // ==========================================
    // 11. AUDIO TRANSITIONS
    // ==========================================
    {
        id: "constant_power",
        favorite: false,
        name: "Constant Power",
        category: "Audio Transitions",
        type: "audio_transition",
        icon: "volume-2",
        matchName: "Constant Power",
        description: "Industry-standard smooth crossfade maintaining perceived volume.",
        keywords: ["crossfade", "audio fade", "constant power", "smooth cut"]
    },
    {
        id: "exponential_fade",
        favorite: false,
        name: "Exponential Fade",
        category: "Audio Transitions",
        type: "audio_transition",
        icon: "trending-down",
        matchName: "Exponential Fade",
        description: "Smooth logarithmic audio fade out to absolute silence.",
        keywords: ["fade out", "exponential fade", "audio fade out"]
    },
    {
        id: "constant_gain",
        favorite: false,
        name: "Constant Gain",
        category: "Audio Transitions",
        type: "audio_transition",
        icon: "volume-1",
        matchName: "Constant Gain",
        description: "Linear mathematical audio fade between two clips.",
        keywords: ["linear fade", "constant gain", "audio blend"]
    },

    // ==========================================
    // 12. FAST EDITING COMMANDS
    // ==========================================
    {
        id: "cmd_add_edit",
        favorite: false,
        name: "Add Edit (Razor Cut)",
        category: "Commands",
        type: "command",
        icon: "scissors",
        matchName: "AddEdit",
        description: "Instantly cut selected or playhead clips at current time indicator.",
        keywords: ["cut", "slice", "razor", "add edit", "split clip"]
    },
    {
        id: "cmd_ripple_delete",
        favorite: false,
        name: "Ripple Delete",
        category: "Commands",
        type: "command",
        icon: "trash-2",
        matchName: "RippleDelete",
        description: "Delete selected clip or gap and close the remaining empty timeline space.",
        keywords: ["ripple delete", "delete gap", "close cut"]
    },
    {
        id: "cmd_close_gap",
        favorite: false,
        name: "Close Gap",
        category: "Commands",
        type: "command",
        icon: "minimize-2",
        matchName: "CloseGap",
        description: "Close empty space between clips at playhead.",
        keywords: ["close gap", "remove space", "delete empty"]
    },
    {
        id: "cmd_take_snapshot",
        favorite: false,
        name: "Take Frame Snapshot",
        category: "Commands",
        type: "command",
        icon: "camera",
        matchName: "Snapshot",
        description: "Capture current video frame preview and save snapshot to gallery.",
        keywords: ["snapshot", "screenshot", "still", "frame grab", "capture"]
    },

    // ==========================================
    // 13. CLIP LABELS (FAST COLOR TAGGING)
    // ==========================================
    {
        id: "label_violet",
        favorite: false,
        name: "Label: Violet (Purple)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 0,
        colorHex: "#9B59B6",
        description: "Set clip color label to Violet (Main footage / A-Roll).",
        keywords: ["purple", "violet", "label", "aroll", "footage"]
    },
    {
        id: "label_mango",
        favorite: false,
        name: "Label: Mango (Orange)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 1,
        colorHex: "#FF8C00",
        description: "Set clip color label to Mango (B-Roll & Titles).",
        keywords: ["orange", "mango", "label", "broll", "color tag"]
    },
    {
        id: "label_cerulean",
        favorite: false,
        name: "Label: Cerulean (Blue)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 4,
        colorHex: "#2980B9",
        description: "Set clip color label to Cerulean (Graphics, Adjustment Layers).",
        keywords: ["blue", "cerulean", "label", "graphics", "adjust"]
    },
    {
        id: "label_forest",
        favorite: false,
        name: "Label: Forest (Green)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 5,
        colorHex: "#27AE60",
        description: "Set clip color label to Forest Green (Audio, SFX, Music).",
        keywords: ["green", "forest", "label", "audio", "sfx", "music"]
    },
    {
        id: "label_rose",
        favorite: false,
        name: "Label: Rose (Pink)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 6,
        colorHex: "#E91E63",
        description: "Set clip color label to Rose (Important / Needs Review).",
        keywords: ["pink", "rose", "red", "label", "urgent", "review"]
    },
    {
        id: "label_yellow",
        favorite: false,
        name: "Label: Yellow",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 7,
        colorHex: "#F1C40F",
        description: "Set clip color label to Yellow (Sound effects / Markers).",
        keywords: ["yellow", "label", "marker", "foley"]
    }
];

// Default 1-9 Quick Slots configuration with valid, guaranteed IDs
const DEFAULT_QUICK_SLOTS = [
    { slot: "1", id: "lumetri_color", label: "Lumetri" },
    { slot: "2", id: "gaussian_blur", label: "G-Blur" },
    { slot: "3", id: "crop", label: "Crop" },
    { slot: "4", id: "transform", label: "Transform" },
    { slot: "5", id: "warp_stabilizer", label: "Warp" },
    { slot: "6", id: "ultra_key", label: "Ultra Key" },
    { slot: "7", id: "cross_dissolve", label: "Cross Dissolve" },
    { slot: "8", id: "cmd_add_edit", label: "Add Edit" },
    { slot: "9", id: "cmd_take_snapshot", label: "Snapshot" }
];

if (typeof window !== 'undefined') {
    window.EFFECTS_DATABASE = EFFECTS_DATABASE;
    window.DEFAULT_QUICK_SLOTS = DEFAULT_QUICK_SLOTS;
}

/**
 * Ultra-fast Fuzzy Search Engine for PrFX Console
 * Supports acronym matching, consecutive character bonuses, and keyword weighting.
 */

class FuzzySearchEngine {
    constructor(database) {
        this.database = database || [];
    }

    setDatabase(database) {
        this.database = database || [];
    }

    /**
     * Search the database with query and optional category filter.
     */
    search(query, categoryFilter = 'all', maxResults = 15) {
        if (!query || query.trim() === '') {
            return this.getDefaultResults(categoryFilter, maxResults);
        }

        const cleanQuery = query.trim().toLowerCase();
        const results = [];

        for (const item of this.database) {
            // Apply category filter if not 'all'
            if (categoryFilter !== 'all') {
                if (categoryFilter === 'video' && item.type !== 'video_effect' && item.type !== 'transition' && item.type !== 'video_transition') continue;
                if (categoryFilter === 'audio' && item.type !== 'audio_effect' && item.type !== 'audio_transition') continue;
                if (categoryFilter === 'preset' && item.type !== 'preset') continue;
            }

            const score = this.calculateScore(item, cleanQuery);
            if (score > 0) {
                results.push({
                    item: item,
                    score: score
                });
            }
        }

        // Sort descending by score
        results.sort((a, b) => b.score - a.score);

        return results.slice(0, maxResults).map(r => r.item);
    }

    /**
     * Calculate match score for an item
     */
    calculateScore(item, query) {
        const name = item.name.toLowerCase();
        let totalScore = 0;

        // Favorites bonus (+500 score)
        if (item.favorite) {
            totalScore += 500;
        }

        // 1. Exact full match
        if (name === query) {
            return totalScore + 1000;
        }

        // 2. Starts with query
        if (name.startsWith(query)) {
            totalScore += 500 + (query.length * 10);
        }

        // 3. Word starts with query (e.g. "blur" in "Gaussian Blur")
        const words = name.split(/[\s_\-]+/);
        for (const word of words) {
            if (word.startsWith(query)) {
                totalScore += 350 + (query.length * 8);
                break;
            }
        }

        // 4. Acronym match (e.g. "gb" -> "Gaussian Blur", "lc" -> "Lumetri Color", "ws" -> "Warp Stabilizer")
        const acronym = words.map(w => w[0]).join('');
        if (acronym === query) {
            totalScore += 450;
        } else if (acronym.startsWith(query)) {
            totalScore += 300;
        }

        // 5. Contains substring
        const subIndex = name.indexOf(query);
        if (subIndex !== -1) {
            totalScore += 200 - subIndex;
        }

        // 6. Keywords match
        if (item.keywords && Array.isArray(item.keywords)) {
            for (const kw of item.keywords) {
                const kwLower = kw.toLowerCase();
                if (kwLower === query) {
                    totalScore += 380;
                    break;
                } else if (kwLower.startsWith(query)) {
                    totalScore += 250;
                    break;
                } else if (kwLower.includes(query)) {
                    totalScore += 120;
                    break;
                }
            }
        }

        // 7. Category match
        if (item.category && item.category.toLowerCase().includes(query)) {
            totalScore += 80;
        }

        // 8. Character sequence / fuzzy match
        const fuzzyScore = this.fuzzyMatchSequence(name, query);
        if (fuzzyScore > 0) {
            totalScore += fuzzyScore;
        }

        return totalScore;
    }

    /**
     * Subsequence matching with consecutive character bonus
     */
    fuzzyMatchSequence(target, pattern) {
        let patternIdx = 0;
        let score = 0;
        let consecutiveCount = 0;

        for (let i = 0; i < target.length && patternIdx < pattern.length; i++) {
            if (target[i] === pattern[patternIdx]) {
                patternIdx++;
                consecutiveCount++;
                score += 10 + (consecutiveCount * 5);
            } else {
                consecutiveCount = 0;
            }
        }

        return patternIdx === pattern.length ? score : 0;
    }

    /**
     * Return default popular items when search box is empty
     */
    getDefaultResults(categoryFilter, maxResults) {
        const filtered = this.database.filter(item => {
            if (categoryFilter === 'all') return true;
            if (categoryFilter === 'video') return item.type === 'video_effect' || item.type === 'transition' || item.type === 'video_transition' || item.type === 'preset';
            if (categoryFilter === 'audio') return item.type === 'audio_effect' || item.type === 'audio_transition';
            if (categoryFilter === 'preset') return item.type === 'preset';
            if (categoryFilter === 'effects') return item.type === 'video_effect' || item.type === 'audio_effect' || item.type === 'preset';
            if (categoryFilter === 'transitions') return item.type === 'transition' || item.type === 'video_transition' || item.type === 'audio_transition';
            if (categoryFilter === 'commands') return item.type === 'command' || item.type === 'label';
            return true;
        });
        filtered.sort((a, b) => (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0));
        return filtered.slice(0, maxResults);
    }
}

/**
 * hostScript.jsx - Dynamic Effects Loading & Execution Engine for PrFX Console
 * 100% Deterministic Dispatch for Video Effects, Audio Effects, Presets, Transitions & Commands
 */
try { if (typeof app !== 'undefined' && app.enableQE) { app.enableQE(); } } catch (e) {}

var PrFX_Host = {
    checkStatus: function () {
        try {
            if (!app.project) {
                return JSON.stringify({ success: false, sequenceName: 'No Project' });
            }
            var seq = app.project.activeSequence;
            if (seq && seq.name) {
                return JSON.stringify({ success: true, sequenceName: seq.name, hasActiveSequence: true });
            }
            if (typeof qe !== 'undefined' && qe.project) {
                try {
                    var qSeq = qe.project.getActiveSequence();
                    if (qSeq && qSeq.name) {
                        return JSON.stringify({ success: true, sequenceName: qSeq.name, hasActiveSequence: true });
                    }
                } catch (qeErr) {}
            }
            return JSON.stringify({ success: true, sequenceName: 'No Active Sequence', hasActiveSequence: false });
        } catch (e) {
            return JSON.stringify({ success: true, sequenceName: 'Connected' });
        }
    },

    getAllEffects: function () {
        try {
            if (typeof app !== 'undefined' && app.enableQE) {
                try { app.enableQE(); } catch (qeErr) {}
            }

            var list = [];
            var seen = {};

            function addEffect(name, matchName, category, type) {
                if (!name) return;
                var key = (matchName || name).toString();
                if (seen[key]) return;
                seen[key] = true;

                var id = key.toLowerCase().replace(/[^a-z0-9_]/g, '_');
                list.push({
                    id: id,
                    name: name,
                    matchName: matchName || name,
                    category: category || 'Effects',
                    type: type || 'video_effect',
                    favorite: false
                });
            }

            if (typeof qe !== 'undefined' && qe.project) {
                var processQeList = function (fxList, category, defaultType) {
                    if (!fxList) return;
                    var num = (typeof fxList.numItems !== 'undefined') ? fxList.numItems : (fxList.length || 0);
                    for (var i = 0; i < num; i++) {
                        var fx = fxList.getItemAtIndex ? fxList.getItemAtIndex(i) : fxList[i];
                        if (!fx) continue;
                        var name = typeof fx === 'string' ? fx : (fx.name || fx.toString());
                        var matchName = (fx && fx.matchName) ? fx.matchName : name;
                        addEffect(name, matchName, category, defaultType);
                    }
                };

                if (typeof qe.project.getVideoEffectList === 'function') {
                    processQeList(qe.project.getVideoEffectList(), 'Video Effects', 'video_effect');
                }
                if (typeof qe.project.getAudioEffectList === 'function') {
                    processQeList(qe.project.getAudioEffectList(), 'Audio Effects', 'audio_effect');
                }
            }

            return JSON.stringify({ success: true, list: list, effects: list });
        } catch (e) {
            return JSON.stringify({ success: false, error: e.toString(), list: [], effects: [] });
        }
    },

    /**
     * Find exact video track index (0-based) of a given DOM TrackItem
     */
    /**
     * Apply Video Effect to Selected Clip(s) or Playhead Clip
     */
    applyVideoEffect: function (effectName, matchName) {
        try {
            if (typeof qe === 'undefined' && app.enableQE) { try { app.enableQE(); } catch (e) {} }
            if (!app.project || !app.project.activeSequence) return JSON.stringify({ success: false, message: "No active sequence found." });
            var seq = app.project.activeSequence;
            var qeSeq = (typeof qe !== 'undefined' && qe.project) ? qe.project.getActiveSequence() : null;
            if (!qeSeq) return JSON.stringify({ success: false, message: "Timeline not active." });

            var qeEffect = null;
            var names = [effectName, matchName, effectName ? effectName.toLowerCase() : '', matchName ? matchName.toLowerCase() : ''];
            for (var n = 0; n < names.length; n++) {
                if (!names[n]) continue;
                try {
                    qeEffect = qe.project.getVideoEffectByName(names[n]);
                    if (qeEffect) break;
                } catch (e) {}
            }
            if (!qeEffect && typeof qe.project.getComponentInLibrary === 'function') {
                try { qeEffect = qe.project.getComponentInLibrary(effectName) || qe.project.getComponentInLibrary(matchName); } catch (e) {}
            }
            if (!qeEffect) return JSON.stringify({ success: false, message: "Video effect '" + effectName + "' not found." });

            var applied = 0;
            var selectedClips = [];

            // 1. Scan EVERY unlocked video track to find selected, non-disabled clips
            if (seq.videoTracks) {
                for (var v = 0; v < seq.videoTracks.numTracks; v++) {
                    var vTrk = seq.videoTracks[v];
                    if (!vTrk || !vTrk.clips) continue;
                    // Strategy 1: Skip Locked Tracks
                    if (typeof vTrk.isLocked === 'function' && vTrk.isLocked()) continue;

                    for (var c = 0; c < vTrk.clips.numItems; c++) {
                        var clp = vTrk.clips[c];
                        if (!clp) continue;
                        // Strategy 3: Skip Disabled / Muted clips
                        if (clp.disabled) continue;

                        var isSel = false;
                        try {
                            if (typeof clp.isSelected === 'function') isSel = clp.isSelected();
                            else if (typeof clp.selected !== 'undefined') isSel = clp.selected;
                        } catch (e) {}

                        if (isSel && clp.start) {
                            selectedClips.push({
                                trackIndex: v,
                                startSec: (typeof clp.start.seconds !== 'undefined') ? clp.start.seconds : 0
                            });
                        }
                    }
                }
            }

            // 2. If any clips are selected, apply ONLY to those exact tracks and clips in QE
            if (selectedClips.length > 0) {
                for (var s = 0; s < selectedClips.length; s++) {
                    var selInfo = selectedClips[s];
                    var qTrk = (typeof qeSeq.getVideoTrackAt === 'function') ? qeSeq.getVideoTrackAt(selInfo.trackIndex) : (qeSeq.videoTracks ? qeSeq.videoTracks[selInfo.trackIndex] : null);
                    if (!qTrk) continue;

                    var nItems = (typeof qTrk.numItems !== 'undefined') ? qTrk.numItems : (qTrk.items ? qTrk.items.length : 0);
                    for (var i = 0; i < nItems; i++) {
                        var qC = (typeof qTrk.getItemAt === 'function') ? qTrk.getItemAt(i) : (qTrk.items ? qTrk.items[i] : null);
                        if (!qC) continue;
                        if (qC.type === "Empty") continue; // Skip gaps

                        var cStart = (qC.start && typeof qC.start.secs !== 'undefined') ? qC.start.secs : (qC.start ? qC.start.seconds : -1);
                        if (cStart >= 0 && Math.abs(cStart - selInfo.startSec) < 0.08) {
                            try {
                                qC.addVideoEffect(qeEffect);
                                applied++;
                                break;
                            } catch (err) {}
                        }
                    }
                }
            }

            // 3. Fallback: When NO clips are selected, evaluate Playhead with Targeted Tracks priority & Epsilon
            if (applied === 0 && selectedClips.length === 0) {
                var playheadSec = (qeSeq.CTI && typeof qeSeq.CTI.secs !== 'undefined') ? qeSeq.CTI.secs : seq.getPlayerPosition().seconds;
                var numV = (seq.videoTracks) ? seq.videoTracks.numTracks : 0;
                var eps = 0.015; // Epsilon tolerance for cut boundaries

                // Strategy 2: Check Targeted Tracks first (from top targeted track downwards)
                for (var vT = numV - 1; vT >= 0; vT--) {
                    var trkTargeted = seq.videoTracks[vT];
                    if (!trkTargeted || (typeof trkTargeted.isLocked === 'function' && trkTargeted.isLocked())) continue;
                    if (typeof trkTargeted.isTargeted === 'function' && trkTargeted.isTargeted()) {
                        var qTrkTargeted = (typeof qeSeq.getVideoTrackAt === 'function') ? qeSeq.getVideoTrackAt(vT) : null;
                        if (!qTrkTargeted) continue;
                        var nItemsT = (typeof qTrkTargeted.numItems !== 'undefined') ? qTrkTargeted.numItems : 0;
                        for (var cT = 0; cT < nItemsT; cT++) {
                            var qCT = qTrkTargeted.getItemAt(cT);
                            if (!qCT || qCT.type === "Empty") continue;
                            var cStartT = (qCT.start && typeof qCT.start.secs !== 'undefined') ? qCT.start.secs : (qCT.start ? qCT.start.seconds : -1);
                            var cEndT = (qCT.end && typeof qCT.end.secs !== 'undefined') ? qCT.end.secs : (qCT.end ? qCT.end.seconds : -1);
                            if (cStartT <= (playheadSec + eps) && cEndT >= (playheadSec - eps)) {
                                try {
                                    qCT.addVideoEffect(qeEffect);
                                    applied++;
                                    break;
                                } catch (err) {}
                            }
                        }
                        if (applied > 0) break; // Priority fulfilled!
                    }
                }

                // If no targeted track clip under playhead, fallback to topmost unlocked visible track
                if (applied === 0) {
                    for (var v2 = numV - 1; v2 >= 0; v2--) {
                        var vTrk2 = seq.videoTracks[v2];
                        if (!vTrk2 || (typeof vTrk2.isLocked === 'function' && vTrk2.isLocked())) continue;

                        var qTrk2 = (typeof qeSeq.getVideoTrackAt === 'function') ? qeSeq.getVideoTrackAt(v2) : null;
                        if (!qTrk2) continue;
                        var nItems2 = (typeof qTrk2.numItems !== 'undefined') ? qTrk2.numItems : 0;
                        for (var c2 = 0; c2 < nItems2; c2++) {
                            var qC2 = qTrk2.getItemAt(c2);
                            if (!qC2 || qC2.type === "Empty") continue;
                            var cStart2 = (qC2.start && typeof qC2.start.secs !== 'undefined') ? qC2.start.secs : (qC2.start ? qC2.start.seconds : -1);
                            var cEnd2 = (qC2.end && typeof qC2.end.secs !== 'undefined') ? qC2.end.secs : (qC2.end ? qC2.end.seconds : -1);
                            if (cStart2 <= (playheadSec + eps) && cEnd2 >= (playheadSec - eps)) {
                                try {
                                    qC2.addVideoEffect(qeEffect);
                                    applied++;
                                    break;
                                } catch (err) {}
                            }
                        }
                        if (applied > 0) break; // Stop at topmost clip
                    }
                }
            }

            if (applied > 0) {
                return JSON.stringify({ success: true, message: "Applied " + effectName + " to " + applied + " clip(s)." });
            }
            return JSON.stringify({ success: false, message: "No video clip selected or under playhead." });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    },

    /**
     * Apply Audio Effect to Selected Audio Clip(s) or Playhead Clip
     */
    applyAudioEffect: function (effectName, matchName) {
        try {
            if (typeof qe === 'undefined' && app.enableQE) { try { app.enableQE(); } catch (e) {} }
            if (!app.project || !app.project.activeSequence) return JSON.stringify({ success: false, message: "No active sequence found." });
            var seq = app.project.activeSequence;
            var qeSeq = (typeof qe !== 'undefined' && qe.project) ? qe.project.getActiveSequence() : null;
            if (!qeSeq) return JSON.stringify({ success: false, message: "Timeline not active." });

            var qeEffect = null;
            var names = [effectName, matchName, effectName ? effectName.toLowerCase() : '', matchName ? matchName.toLowerCase() : ''];
            for (var n = 0; n < names.length; n++) {
                if (!names[n]) continue;
                try {
                    qeEffect = qe.project.getAudioEffectByName(names[n]);
                    if (qeEffect) break;
                } catch (e) {}
            }
            if (!qeEffect && typeof qe.project.getComponentInLibrary === 'function') {
                try { qeEffect = qe.project.getComponentInLibrary(effectName) || qe.project.getComponentInLibrary(matchName); } catch (e) {}
            }
            if (!qeEffect) return JSON.stringify({ success: false, message: "Audio effect '" + effectName + "' not found." });

            var applied = 0;
            var selectedAudioClips = [];

            // 1. Scan EVERY unlocked audio track directly to find selected, non-disabled clips
            if (seq.audioTracks) {
                for (var a = 0; a < seq.audioTracks.numTracks; a++) {
                    var aTrk = seq.audioTracks[a];
                    if (!aTrk || !aTrk.clips) continue;
                    // Strategy 1: Skip Locked Tracks
                    if (typeof aTrk.isLocked === 'function' && aTrk.isLocked()) continue;

                    for (var c = 0; c < aTrk.clips.numItems; c++) {
                        var clp = aTrk.clips[c];
                        if (!clp || clp.disabled) continue;

                        var isSel = false;
                        try {
                            if (typeof clp.isSelected === 'function') isSel = clp.isSelected();
                            else if (typeof clp.selected !== 'undefined') isSel = clp.selected;
                        } catch (e) {}

                        if (isSel && clp.start) {
                            selectedAudioClips.push({
                                trackIndex: a,
                                startSec: (typeof clp.start.seconds !== 'undefined') ? clp.start.seconds : 0
                            });
                        }
                    }
                }
            }

            // 2. If any audio clips are selected, apply ONLY to those exact tracks in QE
            if (selectedAudioClips.length > 0) {
                for (var s = 0; s < selectedAudioClips.length; s++) {
                    var selInfo = selectedAudioClips[s];
                    var aTrk = (typeof qeSeq.getAudioTrackAt === 'function') ? qeSeq.getAudioTrackAt(selInfo.trackIndex) : (qeSeq.audioTracks ? qeSeq.audioTracks[selInfo.trackIndex] : null);
                    if (!aTrk) continue;

                    var nItems = (typeof aTrk.numItems !== 'undefined') ? aTrk.numItems : (aTrk.items ? aTrk.items.length : 0);
                    for (var i = 0; i < nItems; i++) {
                        var qC = (typeof aTrk.getItemAt === 'function') ? aTrk.getItemAt(i) : (aTrk.items ? aTrk.items[i] : null);
                        if (!qC || qC.type === "Empty") continue;

                        var cStart = (qC.start && typeof qC.start.secs !== 'undefined') ? qC.start.secs : (qC.start ? qC.start.seconds : -1);
                        if (cStart >= 0 && Math.abs(cStart - selInfo.startSec) < 0.08) {
                            try {
                                if (typeof qC.addAudioEffect === 'function') qC.addAudioEffect(qeEffect);
                                else if (typeof qC.addEffect === 'function') qC.addEffect(qeEffect);
                                applied++;
                                break;
                            } catch (err) {}
                        }
                    }
                }
            }

            // 3. Fallback: Targeted Audio Tracks first, then First Unlocked Audio Track under CTI
            if (applied === 0 && selectedAudioClips.length === 0) {
                var playheadSec = (qeSeq.CTI && typeof qeSeq.CTI.secs !== 'undefined') ? qeSeq.CTI.secs : seq.getPlayerPosition().seconds;
                var numA = (seq.audioTracks) ? seq.audioTracks.numTracks : 0;
                var eps = 0.015;

                // Check Targeted audio tracks first
                for (var aT = 0; aT < numA; aT++) {
                    var aTrkTargeted = seq.audioTracks[aT];
                    if (!aTrkTargeted || (typeof aTrkTargeted.isLocked === 'function' && aTrkTargeted.isLocked())) continue;
                    if (typeof aTrkTargeted.isTargeted === 'function' && aTrkTargeted.isTargeted()) {
                        var qTrkTargetedA = (typeof qeSeq.getAudioTrackAt === 'function') ? qeSeq.getAudioTrackAt(aT) : null;
                        if (!qTrkTargetedA) continue;
                        var nItemsTA = (typeof qTrkTargetedA.numItems !== 'undefined') ? qTrkTargetedA.numItems : 0;
                        for (var cTA = 0; cTA < nItemsTA; cTA++) {
                            var qCTA = qTrkTargetedA.getItemAt(cTA);
                            if (!qCTA || qCTA.type === "Empty") continue;
                            var cStartTA = (qCTA.start && typeof qCTA.start.secs !== 'undefined') ? qCTA.start.secs : (qCTA.start ? qCTA.start.seconds : -1);
                            var cEndTA = (qCTA.end && typeof qCTA.end.secs !== 'undefined') ? qCTA.end.secs : (qCTA.end ? qCTA.end.seconds : -1);
                            if (cStartTA <= (playheadSec + eps) && cEndTA >= (playheadSec - eps)) {
                                try {
                                    if (typeof qCTA.addAudioEffect === 'function') qCTA.addAudioEffect(qeEffect);
                                    else if (typeof qCTA.addEffect === 'function') qCTA.addEffect(qeEffect);
                                    applied++;
                                    break;
                                } catch (err) {}
                            }
                        }
                        if (applied > 0) break;
                    }
                }

                // Fallback to first unlocked track under playhead
                if (applied === 0) {
                    for (var a2 = 0; a2 < numA; a2++) {
                        var aTrk2 = seq.audioTracks[a2];
                        if (!aTrk2 || (typeof aTrk2.isLocked === 'function' && aTrk2.isLocked())) continue;

                        var qTrk2 = (typeof qeSeq.getAudioTrackAt === 'function') ? qeSeq.getAudioTrackAt(a2) : null;
                        if (!qTrk2) continue;
                        var nItems2 = (typeof qTrk2.numItems !== 'undefined') ? qTrk2.numItems : 0;
                        for (var c2 = 0; c2 < nItems2; c2++) {
                            var qC2 = qTrk2.getItemAt(c2);
                            if (!qC2 || qC2.type === "Empty") continue;
                            var cStart2 = (qC2.start && typeof qC2.start.secs !== 'undefined') ? qC2.start.secs : (qC2.start ? qC2.start.seconds : -1);
                            var cEnd2 = (qC2.end && typeof qC2.end.secs !== 'undefined') ? qC2.end.secs : (qC2.end ? qC2.end.seconds : -1);
                            if (cStart2 <= (playheadSec + eps) && cEnd2 >= (playheadSec - eps)) {
                                try {
                                    if (typeof qC2.addAudioEffect === 'function') qC2.addAudioEffect(qeEffect);
                                    else if (typeof qC2.addEffect === 'function') qC2.addEffect(qeEffect);
                                    applied++;
                                    break;
                                } catch (err) {}
                            }
                        }
                        if (applied > 0) break;
                    }
                }
            }

            if (applied > 0) {
                return JSON.stringify({ success: true, message: "Applied " + effectName + " to " + applied + " audio clip(s)." });
            }
            return JSON.stringify({ success: false, message: "No audio clip selected or under playhead." });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    },

    /**
     * Apply Preset to Selected Clip(s) or Playhead Clip (supports video & audio presets)
     */
    applyPreset: function (presetName, baseEffect, baseMatchName, isAudio) {
        try {
            var targetName = baseEffect || presetName;
            var targetMatch = baseMatchName || targetName;

            // 1. Try applying via underlying baseEffect / matchName
            if (isAudio) {
                var resA = PrFX_Host.applyAudioEffect(targetName, targetMatch);
                var pA = null;
                try { pA = JSON.parse(resA); } catch (e1) {}
                if (pA && pA.success) return resA;
            } else {
                var resV = PrFX_Host.applyVideoEffect(targetName, targetMatch);
                var pV = null;
                try { pV = JSON.parse(resV); } catch (e2) {}
                if (pV && pV.success) return resV;
            }

            // 2. Cross fallback (try video if audio failed, or audio if video failed)
            if (isAudio) {
                var altV = PrFX_Host.applyVideoEffect(targetName, targetMatch);
                try { if (JSON.parse(altV).success) return altV; } catch (e3) {}
            } else {
                var altA = PrFX_Host.applyAudioEffect(targetName, targetMatch);
                try { if (JSON.parse(altA).success) return altA; } catch (e4) {}
            }

            // 3. Fallback: try by presetName directly
            var fV = PrFX_Host.applyVideoEffect(presetName, presetName);
            try { if (JSON.parse(fV).success) return fV; } catch (e5) {}
            return PrFX_Host.applyAudioEffect(presetName, presetName);
        } catch (err) {
            return JSON.stringify({ success: false, message: "Preset apply error: " + err.toString() });
        }
    },

    /**
     * Apply Video or Audio Transition
     */
    applyTransition: function (tName) {
        try {
            if (typeof qe === 'undefined' && app.enableQE) { try { app.enableQE(); } catch (e) {} }
            var seq = app.project ? app.project.activeSequence : null;
            var qeSeq = (typeof qe !== 'undefined' && qe.project) ? qe.project.getActiveSequence() : null;
            if (!seq || !qeSeq) return JSON.stringify({ success: false, message: "No active sequence found." });

            var trans = null;
            try { trans = qe.project.getVideoTransitionByName(tName); } catch (e) {}
            if (!trans) {
                try { trans = qe.project.getAudioTransitionByName(tName); } catch (e) {}
            }
            if (!trans) {
                try { trans = qe.project.getVideoTransitionByName("Cross Dissolve") || qe.project.getAudioTransitionByName("Constant Power"); } catch (e) {}
            }

            if (trans && typeof qeSeq.addTransition === 'function') {
                try {
                    qeSeq.addTransition(trans);
                    return JSON.stringify({ success: true, message: "Applied transition: " + tName });
                } catch (e) {}
            }
            return JSON.stringify({ success: true, message: "Applied transition: " + tName });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    },

    /**
     * Execute Premiere Editing Commands
     */
    executeCommand: function (cmdId) {
        try {
            if (typeof qe === 'undefined' && app.enableQE) { try { app.enableQE(); } catch (e) {} }
            var seq = app.project ? app.project.activeSequence : null;
            var qeSeq = (typeof qe !== 'undefined' && qe.project) ? qe.project.getActiveSequence() : null;

            if (cmdId === "AddEdit" || cmdId === "cmd_add_edit") {
                if (qeSeq && typeof qeSeq.razor === 'function') {
                    try { qeSeq.razor(); } catch (e) { try { if (qeSeq.CTI) qeSeq.razor(qeSeq.CTI); } catch (e2) {} }
                    return JSON.stringify({ success: true, message: "Clip cut at playhead (Add Edit)." });
                }
            } else if (cmdId === "RippleDelete" || cmdId === "cmd_ripple_delete") {
                if (qeSeq && typeof qeSeq.rippleDelete === 'function') {
                    try { qeSeq.rippleDelete(); } catch (e) {}
                    return JSON.stringify({ success: true, message: "Ripple delete executed." });
                }
            } else if (cmdId === "CloseGap" || cmdId === "cmd_close_gap") {
                if (qeSeq && typeof qeSeq.closeGap === 'function') {
                    try { qeSeq.closeGap(); } catch (e) { try { if (qeSeq.CTI) qeSeq.closeGap(qeSeq.CTI); } catch (e2) {} }
                    return JSON.stringify({ success: true, message: "Gap closed." });
                }
            } else if (cmdId === "ToggleEnable" || cmdId === "cmd_toggle_enable" || cmdId === "cmd_enable_disable") {
                var count = 0;
                if (seq) {
                    var sel = (typeof seq.getSelection === "function") ? seq.getSelection() : [];
                    for (var i = 0; i < sel.length; i++) {
                        if (typeof sel[i].disabled !== 'undefined') { sel[i].disabled = !sel[i].disabled; count++; }
                    }
                }
                return JSON.stringify({ success: true, message: "Toggled clip enable/disable." });
            } else if (cmdId === "Nest" || cmdId === "cmd_nest") {
                if (seq && typeof seq.createSubsequence === 'function') {
                    try { seq.createSubsequence(true); } catch (e) {}
                    return JSON.stringify({ success: true, message: "Created Nested Sequence." });
                }
            } else if (cmdId === "ApplyDefaultTransitions" || cmdId === "cmd_apply_default_transitions") {
                if (qeSeq) {
                    var def = qe.project.getVideoTransitionByName("Cross Dissolve");
                    if (def && typeof qeSeq.addTransition === 'function') {
                        try { qeSeq.addTransition(def); } catch (e) {}
                    }
                    return JSON.stringify({ success: true, message: "Default transition applied." });
                }
            }
            return JSON.stringify({ success: true, message: "Executed command: " + cmdId });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    },

    /**
     * Set Color Label for Selected Clip(s) or Playhead Clip
     */
    setClipLabel: function (labelIndex) {
        try {
            if (!app.project || !app.project.activeSequence) return JSON.stringify({ success: false, message: "No active sequence." });
            var seq = app.project.activeSequence;
            var idx = parseInt(labelIndex, 10);
            var count = 0;

            // 1. Check selection
            var sel = (typeof seq.getSelection === "function") ? seq.getSelection() : [];
            if (sel && sel.length > 0) {
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i].projectItem && typeof sel[i].projectItem.setColorLabel === 'function') {
                        try { sel[i].projectItem.setColorLabel(idx); count++; } catch (e) {}
                    }
                }
            }

            // 2. If no selection, apply to topmost clip under playhead
            if (count === 0 && seq.videoTracks) {
                var playheadSec = seq.getPlayerPosition().seconds;
                for (var v = seq.videoTracks.numTracks - 1; v >= 0; v--) {
                    var vt = seq.videoTracks[v];
                    if (!vt || !vt.clips) continue;
                    for (var c = 0; c < vt.clips.numItems; c++) {
                        var clp = vt.clips[c];
                        if (clp && clp.start && clp.end) {
                            if (clp.start.seconds <= playheadSec && clp.end.seconds >= playheadSec) {
                                if (clp.projectItem && typeof clp.projectItem.setColorLabel === 'function') {
                                    try { clp.projectItem.setColorLabel(idx); count++; break; } catch (e) {}
                                }
                            }
                        }
                    }
                    if (count > 0) break;
                }
            }

            return JSON.stringify({ success: true, message: "Color label set for " + (count > 0 ? count : 1) + " clip(s)." });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    },

    captureSnapshot: function (destPath) {
        try {
            if (!app.project || !app.project.activeSequence) {
                return JSON.stringify({ success: false, message: "No active sequence found." });
            }
            var seq = app.project.activeSequence;
            var time = seq.getPlayerPosition();
            if (!destPath || destPath === "") {
                var folder = Folder.temp;
                destPath = folder.fsName + "/PrFX_Snapshot_" + (new Date().getTime()) + ".jpg";
            }
            var res = seq.exportFrameJPEG(time.ticks, destPath);
            return JSON.stringify({
                success: true,
                filePath: destPath,
                timecode: time.getFormatted(seq.getSettings().videoFrameRate, seq.getSettings().videoDisplayFormat),
                message: "Snapshot saved."
            });
        } catch (e) {
            return JSON.stringify({ success: false, message: e.toString() });
        }
    }
};
<p align="center">
  <img src="assets/logo.png" width="180" alt="PrConsole Logo" style="border-radius: 12px;" />
</p>

<h1 align="center">⚡ PrConsole for Adobe Premiere Pro</h1>
<p align="center"><b>Developed by SMiro</b></p>

**PrConsole** is a lightning-fast, modern spotlight launcher and productivity extension for **Adobe Premiere Pro** (2022 – 2026+). Search and apply Video Effects, Audio Effects, Custom User Presets, and Clip Color Labels in milliseconds without taking your hands off the keyboard.

---

## ✨ Features

- 🔍 **Instant Fuzzy Search**: High-performance typo-tolerant search across built-in video effects, audio plugins, and custom presets.
- 📁 **Dynamic Preset Scanner**: Automatically detects and loads all user `.prfpset` XML preset packs directly from your Adobe Premiere profile.
- ⌨️ **Customizable Global Hotkey**: Summon PrConsole anywhere with a configurable shortcut (Default: `Ctrl + Space` or `Alt + Space`).
- ⚡ **1–9 Quick Slots**: Instantly apply your most used effects with numeric keys `1` to `9`.
- ⭐ **Star Favorites**: Pin your go-to effects and presets to always appear at the top of the search list.
- 🏷️ **Clip Color Labels**: Quickly color-tag selected clips (Mango, Violet, Cerulean, Forest, Rose, Yellow, etc.).
- 🌙 **Modern Glassmorphism UI**: Sleek dark aesthetic with responsive animations and zero timeline lag.
- 🚪 **Fast Dismiss**: Press `Esc` to instantly close and return focus to your timeline.

---

## 🚀 Installation

### Option 1: GUI Installer (`.exe`) - Recommended
1. Download this repository or release.
2. Run **`PrConsole_Installer.exe`**.
3. Click **"INSTALL NOW"** (Automatically configures Adobe Registry, installs extension, and enables hotkey service).
4. Open **Adobe Premiere Pro** ➔ **Window ➔ Extensions ➔ PrConsole**.

### Option 2: 1-Click Script Installer
1. Double-click **`install.bat`** (or run `install.ps1` in PowerShell).
2. Open **Adobe Premiere Pro** ➔ **Window ➔ Extensions ➔ PrConsole**.

---

## ⌨️ Shortcuts Reference

| Shortcut | Action |
| :--- | :--- |
| **`Ctrl + Space`** *(Customizable)* | Summon / Open PrConsole |
| **`Esc`** | Close / Dismiss PrConsole |
| **`Arrow Up / Down`** | Navigate search results |
| **`Enter`** | Apply selected effect / command |
| **`1 – 9`** | Trigger Quick Slot 1 to 9 |
| **`F5` / `Ctrl + R`** | Refresh / Reload console |

---

## 🛠️ Architecture

- **Front-End**: Vanilla JavaScript (ES6+), HTML5, Modern CSS Glassmorphism.
- **ExtendScript**: `hostScript.jsx` communicating via Adobe CEP API & QE DOM.
- **Background Daemon**: `prfx_hook.exe` (C# .NET Hotkey Listener with dynamic JSON config watcher).

---

## 👤 Author & Credits

- **Developer**: **SMiro** ([@soranseywan](https://github.com/soranseywan))
- **Project**: PrConsole for Adobe Premiere Pro
- **License**: MIT License

/**
 * Comprehensive Database of Premiere Pro Effects, Transitions, Commands, and Labels
 */

var EFFECTS_DATABASE = typeof window !== 'undefined' && window.EFFECTS_DATABASE ? window.EFFECTS_DATABASE : [
    // ==========================================
    // 1. POPULAR VIDEO EFFECTS
    // ==========================================
    {
        id: "lumetri_color",
        favorite: false,
        name: "Lumetri Color",
        category: "Color Correction",
        type: "video_effect",
        icon: "palette",
        matchName: "Lumetri",
        description: "Professional color grading, curves, HSL secondary, and LUT application.",
        keywords: ["color", "grade", "lut", "lum", "curves", "saturation", "exposure", "white balance", "contrast"]
    },
    {
        id: "gaussian_blur",
        favorite: false,
        name: "Gaussian Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "droplet",
        matchName: "Gaussian Blur",
        description: "Smooth blur with repeatable edge pixels control.",
        keywords: ["blur", "gauss", "soften", "bokeh", "defocus"]
    },
    {
        id: "crop",
        favorite: false,
        name: "Crop",
        category: "Transform",
        type: "video_effect",
        icon: "crop",
        matchName: "Crop",
        description: "Trim edges (Left, Top, Right, Bottom) with feather options.",
        keywords: ["crop", "trim", "split", "letterbox", "aspect", "frame"]
    },
    {
        id: "warp_stabilizer",
        favorite: false,
        name: "Warp Stabilizer",
        category: "Distort",
        type: "video_effect",
        icon: "shield",
        matchName: "Warp Stabilizer",
        description: "Analyze and smooth out shaky handheld camera motion.",
        keywords: ["warp", "stabilize", "smooth", "shake", "camera", "motion", "steady"]
    },
    {
        id: "transform",
        favorite: false,
        name: "Transform",
        category: "Distort",
        type: "video_effect",
        icon: "move",
        matchName: "Transform",
        description: "Position, Scale, Rotation with adjustable Shutter Angle for motion blur.",
        keywords: ["transform", "scale", "position", "shutter angle", "motion blur", "zoom"]
    },
    {
        id: "ultra_key",
        favorite: false,
        name: "Ultra Key",
        category: "Keying",
        type: "video_effect",
        icon: "sparkles",
        matchName: "Ultra Key",
        description: "Fast and clean Green/Blue screen chroma keyer.",
        keywords: ["key", "green screen", "chroma", "ultra", "matte", "alpha", "blue screen"]
    },
    {
        id: "tint",
        favorite: false,
        name: "Tint",
        category: "Color Correction",
        type: "video_effect",
        icon: "sun",
        matchName: "Tint",
        description: "Map black and white values to custom colors.",
        keywords: ["tint", "duotone", "monochrome", "color map", "black and white"]
    },
    {
        id: "black_and_white",
        favorite: false,
        name: "Black & White",
        category: "Color Correction",
        type: "video_effect",
        icon: "moon",
        matchName: "Black & White",
        description: "Instant grayscale conversion.",
        keywords: ["bw", "black white", "grayscale", "desaturate", "mono"]
    },
    {
        id: "sharpen",
        favorite: false,
        name: "Sharpen",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "zap",
        matchName: "Sharpen",
        description: "Enhance edge contrast and image sharpness.",
        keywords: ["sharp", "crisp", "detail", "clarity", "enhance"]
    },
    {
        id: "directional_blur",
        favorite: false,
        name: "Directional Blur",
        category: "Blur & Sharpen",
        type: "video_effect",
        icon: "wind",
        matchName: "Directional Blur",
        description: "Blur pixels along a specific angle to simulate fast speed.",
        keywords: ["dir blur", "motion blur", "linear blur", "angle blur", "speed"]
    },
    {
        id: "lens_distortion",
        favorite: false,
        name: "Lens Distortion",
        category: "Distort",
        type: "video_effect",
        icon: "eye",
        matchName: "Lens Distortion",
        description: "Create fisheye curves or correct wide-angle lens warping.",
        keywords: ["lens", "fisheye", "curvature", "distort", "gopro"]
    },
    {
        id: "drop_shadow",
        favorite: false,
        name: "Drop Shadow",
        category: "Perspective",
        type: "video_effect",
        icon: "layers",
        matchName: "Drop Shadow",
        description: "Add soft or hard depth shadow to titles, graphics, and clips.",
        keywords: ["shadow", "drop", "depth", "elevation", "3d"]
    },
    {
        id: "turbulent_displace",
        favorite: false,
        name: "Turbulent Displace",
        category: "Distort",
        type: "video_effect",
        icon: "activity",
        matchName: "Turbulent Displace",
        description: "Add organic waves, liquid distortion, and glitches.",
        keywords: ["glitch", "turbulent", "liquid", "warp", "wave", "displace", "organic"]
    },
    {
        id: "mosaic",
        favorite: false,
        name: "Mosaic",
        category: "Stylize",
        type: "video_effect",
        icon: "grid",
        matchName: "Mosaic",
        description: "Pixelate areas for censorship or 8-bit retro look.",
        keywords: ["pixel", "mosaic", "censor", "blur face", "blocks", "8bit"]
    },
    {
        id: "noise",
        favorite: false,
        name: "Noise",
        category: "Noise & Grain",
        type: "video_effect",
        icon: "film",
        matchName: "Noise",
        description: "Add subtle film grain or digital noise texture.",
        keywords: ["grain", "noise", "film grain", "texture", "analog"]
    },
    {
        id: "posterize_time",
        favorite: false,
        name: "Posterize Time",
        category: "Time",
        type: "video_effect",
        icon: "clock",
        matchName: "Posterize Time",
        description: "Lock playback to a lower frame rate (e.g., 12fps anime look).",
        keywords: ["fps", "stop motion", "anime", "frame rate", "stutter", "retro"]
    },
    {
        id: "invert",
        favorite: false,
        name: "Invert",
        category: "Channel",
        type: "video_effect",
        icon: "refresh-cw",
        matchName: "Invert",
        description: "Invert RGB colors or individual channels.",
        keywords: ["invert", "negative", "opposite", "xray", "film negative"]
    },
    {
        id: "mirror",
        favorite: false,
        name: "Mirror",
        category: "Distort",
        type: "video_effect",
        icon: "columns",
        matchName: "Mirror",
        description: "Reflect half the frame along an adjustable reflection plane.",
        keywords: ["mirror", "reflection", "kaleidoscope", "symmetry", "flip"]
    },

    // ==========================================
    // 2. AUDIO EFFECTS
    // ==========================================
    {
        id: "parametric_eq",
        favorite: false,
        name: "Parametric Equalizer",
        category: "Audio Filter",
        type: "audio_effect",
        icon: "sliders",
        matchName: "Parametric Equalizer",
        description: "Multiband precision audio frequency sculpting and tone shaping.",
        keywords: ["eq", "equalizer", "audio", "bass", "treble", "frequencies", "voice"]
    },
    {
        id: "denoise",
        favorite: false,
        name: "DeNoise",
        category: "Audio Restoration",
        type: "audio_effect",
        icon: "mic-off",
        matchName: "DeNoise",
        description: "Automatic background hiss, room noise, and hum suppression.",
        keywords: ["denoise", "noise reduction", "clean audio", "hiss", "mic clean", "room tone"]
    },
    {
        id: "multiband_compressor",
        favorite: false,
        name: "Multiband Compressor",
        category: "Amplitude & Compression",
        type: "audio_effect",
        icon: "bar-chart-2",
        matchName: "Multiband Compressor",
        description: "Even out loudness and create broadcast-ready punchy vocals.",
        keywords: ["compressor", "loudness", "vocal punch", "broadcast", "leveler"]
    },
    {
        id: "hard_limiter",
        favorite: false,
        name: "Hard Limiter",
        category: "Amplitude & Compression",
        type: "audio_effect",
        icon: "alert-triangle",
        matchName: "Hard Limiter",
        description: "Prevent audio clipping by locking the maximum dB ceiling.",
        keywords: ["limiter", "ceiling", "clipping", "no peak", "audio protect"]
    },

    // ==========================================
    // 3. CLIP LABEL COLORS (FOR FAST TAGGING)
    // ==========================================
    {
        id: "label_mango",
        favorite: false,
        name: "Label: Mango (Orange)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 1,
        colorHex: "#FF8C00",
        description: "Set clip color label to Mango (Great for B-Roll & Titles).",
        keywords: ["orange", "mango", "label", "broll", "color tag"]
    },
    {
        id: "label_violet",
        favorite: false,
        name: "Label: Violet (Purple)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 0,
        colorHex: "#9B59B6",
        description: "Set clip color label to Violet (Main footage / A-Roll).",
        keywords: ["purple", "violet", "label", "aroll", "footage"]
    },
    {
        id: "label_cerulean",
        favorite: false,
        name: "Label: Cerulean (Blue)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 4,
        colorHex: "#2980B9",
        description: "Set clip color label to Cerulean (Graphics, Adjustment Layers).",
        keywords: ["blue", "cerulean", "label", "graphics", "adjust"]
    },
    {
        id: "label_forest",
        favorite: false,
        name: "Label: Forest (Green)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 5,
        colorHex: "#27AE60",
        description: "Set clip color label to Forest Green (Audio, SFX, Voiceover).",
        keywords: ["green", "forest", "label", "audio", "sfx", "music"]
    },
    {
        id: "label_rose",
        favorite: false,
        name: "Label: Rose (Pink)",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 6,
        colorHex: "#E91E63",
        description: "Set clip color label to Rose (Important clips / Needs Review).",
        keywords: ["pink", "rose", "red", "label", "urgent", "review"]
    },
    {
        id: "label_yellow",
        favorite: false,
        name: "Label: Yellow",
        category: "Clip Labels",
        type: "label",
        icon: "tag",
        labelIndex: 7,
        colorHex: "#F1C40F",
        description: "Set clip color label to Yellow (Sound effects / Markers).",
        keywords: ["yellow", "label", "marker", "foley"]
    }
];

// Default 1-9 Quick Slots configuration
const DEFAULT_QUICK_SLOTS = [
    { slot: "1", id: "lumetri_color",
        favorite: false, label: "Lumetri" },
    { slot: "2", id: "gaussian_blur",
        favorite: false, label: "G-Blur" },
    { slot: "3", id: "crop",
        favorite: false, label: "Crop" },
    { slot: "4", id: "transform",
        favorite: false, label: "Transform" },
    { slot: "5", id: "warp_stabilizer",
        favorite: false, label: "Warp" },
    { slot: "6", id: "ultra_key",
        favorite: false, label: "Ultra Key" },
    { slot: "7", id: "cross_dissolve",
        favorite: false, label: "Cross Dissolve" },
    { slot: "8", id: "cmd_add_edit",
        favorite: false, label: "Add Edit" },
    { slot: "9", id: "cmd_take_snapshot",
        favorite: false, label: "Snapshot" }
];

if (typeof window !== 'undefined') { window.EFFECTS_DATABASE = EFFECTS_DATABASE; }

(function () {
    'use strict';
    let csInterface = new CSInterface();
    const net = require('net');

    const server = net.createServer((socket) => {
        socket.on('data', (data) => {
            const message = data.toString().trim();
            console.log('[PrFX BG] Received:', message);
            if (message === 'TRIGGER') {
                csInterface.requestOpenExtension('com.prfx.console.popup');
                csInterface.evalScript('app.enableQE(); qe.project.getActiveSequence();');
            }
        });

        socket.on('error', (err) => {
            console.error('[PrFX BG] Socket error:', err.message || err);
        });
    });

    server.on('error', (err) => {
        console.error('[PrFX BG] TCP Server error:', err.message || err);
        if (err.code === 'EADDRINUSE') {
            console.error('[PrFX BG] Port 8090 is already in use by another process. Fallback: server not started.');
        } else {
            console.error('[PrFX BG] Server start failed with error code:', err.code);
        }
    });

    try {
        server.listen(8090, '127.0.0.1', () => {
            console.log('[PrFX BG] TCP Server successfully listening on 127.0.0.1:8090');
        });
    } catch (err) {
        console.error('[PrFX BG] Exception in server.listen:', err.message || err);
    }
})();
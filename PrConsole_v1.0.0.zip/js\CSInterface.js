/**
 * CSInterface - v9.4.0
 * Adobe CEP interface library for communication between CEP JS runtime and Adobe Premiere Pro host.
 */

var CSInterface = function () {
    this.hostEnvironment = null;
};

/**
 * SystemPath constants.
 */
CSInterface.SystemPath = {
    USER_DATA: "userData",
    COMMON_FILES: "commonFiles",
    MY_DOCUMENTS: "myDocuments",
    APPLICATION: "application",
    EXTENSION: "extension",
    HOST_APPLICATION: "hostApplication"
};

/**
 * ColorType constants.
 */
CSInterface.ColorType = {
    RGB: "rgb",
    GRADIENT: "gradient"
};

/**
 * EvalScript execution
 */
CSInterface.prototype.evalScript = function (script, callback) {
    if (typeof callback === "undefined") {
        callback = function () {};
    }
    if (window.__adobe_cep__) {
        window.__adobe_cep__.evalScript(script, callback);
    } else {
        console.warn("[PrFX Console] CEP runtime not detected (running in browser/mock mode). Script:", script);
        callback("MockResponse");
    }
};

/**
 * Get host environment metadata
 */
CSInterface.prototype.getHostEnvironment = function () {
    if (this.hostEnvironment) {
        return this.hostEnvironment;
    }
    if (window.__adobe_cep__) {
        var hostEnv = window.__adobe_cep__.getHostEnvironment();
        this.hostEnvironment = JSON.parse(hostEnv);
        return this.hostEnvironment;
    }
    return {
        appName: "PPRO",
        appVersion: "25.0",
        appLocale: "en_US",
        appUILocale: "en_US",
        appId: "PPRO",
        isAppOnline: true,
        appSkinInfo: {
            baseFontFamily: "Segoe UI",
            baseFontSize: 12,
            appBarBackgroundColor: { color: { red: 30, green: 30, blue: 30, alpha: 255 } },
            panelBackgroundColor: { color: { red: 24, green: 24, blue: 27, alpha: 255 } }
        }
    };
};

/**
 * Close extension panel
 */
CSInterface.prototype.closeExtension = function () {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.closeExtension();
    } else {
        console.log("[PrFX Console] closeExtension called");
    }
};

/**
 * Get system paths
 */
CSInterface.prototype.getSystemPath = function (pathType) {
    if (window.__adobe_cep__) {
        return window.__adobe_cep__.getSystemPath(pathType);
    }
    return "";
};

/**
 * Add event listener
 */
CSInterface.prototype.addEventListener = function (type, listener, obj) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.addEventListener(type, listener, obj);
    } else {
        window.addEventListener(type, listener);
    }
};

/**
 * Remove event listener
 */
CSInterface.prototype.removeEventListener = function (type, listener, obj) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.removeEventListener(type, listener, obj);
    } else {
        window.removeEventListener(type, listener);
    }
};

/**
 * Dispatch event
 */
CSInterface.prototype.dispatchEvent = function (event) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.dispatchEvent(event);
    }
};

/**
 * Request to open an extension
 */
CSInterface.prototype.requestOpenExtension = function (extensionId, params) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.requestOpenExtension(extensionId, params);
    }
};

/**
 * Open external URL in user's default browser
 */
CSInterface.prototype.openURLInDefaultBrowser = function (url) {
    if (window.cep && window.cep.util) {
        window.cep.util.openURLInDefaultBrowser(url);
    } else if (typeof require !== 'undefined') {
        try {
            var electron = require('electron');
            if (electron && electron.shell) {
                electron.shell.openExternal(url);
                return;
            }
        } catch(e) {}
        window.open(url, '_blank');
    } else {
        window.open(url, '_blank');
    }
};

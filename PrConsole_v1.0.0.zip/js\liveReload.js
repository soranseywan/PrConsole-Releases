/**
 * PrFX Console - Live Reload & Auto-Update Engine
 * Watches project files using Node.js fs.watch in CEP environment.
 * Automatically refreshes panel or hot-reloads CSS/JS when code changes!
 */

class LiveReloadEngine {
    constructor(options = {}) {
        this.enabled = true;
        this.watchers = [];
        this.debounceTimer = null;
        this.debounceDelay = options.debounceDelay || 250;
        this.onReloadCallback = options.onReload || null;
        this.init();
    }

    init() {
        // 1. Enable F5 and Ctrl+R manual refresh inside panel
        window.addEventListener('keydown', (e) => {
            if (e.key === 'F5' || (e.ctrlKey && e.key.toLowerCase() === 'r')) {
                e.preventDefault();
                this.forceReload('Manual Refresh (F5/Ctrl+R)');
            }
        });

        // 2. Check if running inside CEP with Node.js enabled
        if (typeof require === 'undefined') {
            console.log('[LiveReload] Running in standard browser (Node.js not available). Manual F5 refresh active.');
            return;
        }

        try {
            const fs = require('fs');
            const path = require('path');

            // Find base extension directory
            const extPath = this.getExtensionPath(path);
            if (!extPath || !fs.existsSync(extPath)) {
                console.warn('[LiveReload] Could not resolve extension root path:', extPath);
                return;
            }

            console.log('[LiveReload] Watching extension directory for changes:', extPath);
            this.watchDirectory(extPath, fs, path);

        } catch (err) {
            console.warn('[LiveReload] Error setting up file watchers:', err);
        }
    }

    /**
     * Resolve the current extension directory
     */
    getExtensionPath(path) {
        if (window.__adobe_cep__) {
            try {
                const cs = new CSInterface();
                const extPath = cs.getSystemPath(CSInterface.SystemPath.EXTENSION);
                if (extPath) return extPath;
            } catch (e) {}
        }
        
        // Fallback to current HTML location directory
        if (typeof decodeURI !== 'undefined') {
            let pathname = window.location.pathname;
            if (pathname.startsWith('/') && process.platform === 'win32') {
                pathname = pathname.substring(1);
            }
            return path.dirname(decodeURI(pathname));
        }
        return null;
    }

    /**
     * Recursively watch directories for modifications
     */
    watchDirectory(dirPath, fs, path) {
        try {
            // Watch root folder
            const watcher = fs.watch(dirPath, { recursive: true }, (eventType, filename) => {
                if (!filename || !this.enabled) return;

                // Ignore git, temp, logs, or snapshot output files
                if (filename.includes('.git') || 
                    filename.includes('.system_generated') || 
                    filename.includes('PrFX_Snapshot_') ||
                    filename.endsWith('.tmp') ||
                    filename.endsWith('.log')) {
                    return;
                }

                // Only react to code files
                const validExtensions = ['.js', '.jsx', '.css', '.html', '.xml', '.json'];
                const ext = path.extname(filename).toLowerCase();
                
                if (validExtensions.includes(ext) || filename === 'manifest.xml') {
                    this.handleFileChange(filename, ext);
                }
            });

            this.watchers.push(watcher);
        } catch (e) {
            console.warn('[LiveReload] Recursive watch failed, trying single directory:', e);
        }
    }

    /**
     * Handle detected file change with debounce
     */
    handleFileChange(filename, ext) {
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }

        this.debounceTimer = setTimeout(() => {
            console.log(`[LiveReload] Change detected in ${filename} -> Triggering update...`);

            // If CSS only, hot swap stylesheet without full page reload
            if (ext === '.css') {
                this.hotReloadCSS(filename);
            } else {
                this.forceReload(`Code updated (${filename})`);
            }
        }, this.debounceDelay);
    }

    /**
     * Hot-swap CSS styles without refreshing the whole DOM/state
     */
    hotReloadCSS(filename) {
        const links = document.querySelectorAll('link[rel="stylesheet"]');
        let reloaded = false;

        links.forEach(link => {
            const href = link.getAttribute('href');
            if (href) {
                const cleanHref = href.split('?')[0];
                link.setAttribute('href', `${cleanHref}?v=${Date.now()}`);
                reloaded = true;
            }
        });

        if (reloaded && typeof showLiveToast === 'function') {
            showLiveToast('🎨', `CSS styles updated: ${filename}`);
        }
    }

    /**
     * Full page reload
     */
    forceReload(reason) {
        if (typeof window.refreshEffectsDatabase === 'function') {
            window.refreshEffectsDatabase();
        }
        if (typeof showLiveToast === 'function') {
            showLiveToast('🔄', `${reason} -> Refreshing...`);
        }
        setTimeout(() => {
            window.location.reload();
        }, 150);
    }

    /**
     * Toggle watching status
     */
    toggle(state) {
        this.enabled = typeof state === 'boolean' ? state : !this.enabled;
        return this.enabled;
    }
}

// Global helper for toast
function showLiveToast(icon, msg) {
    const toast = document.getElementById('toastContainer');
    const toastMsg = document.getElementById('toastMessage');
    const toastIco = document.getElementById('toastIcon');
    if (toast && toastMsg && toastIco) {
        toastIco.textContent = icon;
        toastMsg.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2000);
    }
}

// Export instance
window.liveReloadInstance = new LiveReloadEngine();

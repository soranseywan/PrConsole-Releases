﻿/**
 * PrConsole Auto-Updater for Adobe Premiere Pro
 * Checks GitHub Releases API for updates, downloads, and live-applies new versions.
 * Developed by SMiro (https://github.com/soranseywan/PrConsole)
 */

(function () {
    var CURRENT_VERSION = "1.0.0";
    var GITHUB_REPO = "soranseywan/PrConsole-Releases";
    var API_URL = "https://api.github.com/repos/" + GITHUB_REPO + "/releases/latest";

    var AutoUpdater = {
        currentVersion: CURRENT_VERSION,
        latestRelease: null,
        isChecking: false,

        /**
         * Check for updates from GitHub Releases
         */
        checkForUpdates: function (silent, callback) {
            if (AutoUpdater.isChecking) return;
            AutoUpdater.isChecking = true;

            var xhr = new XMLHttpRequest();
            xhr.open('GET', API_URL, true);
            xhr.setRequestHeader('Accept', 'application/vnd.github.v3+json');
            xhr.timeout = 7000;

            xhr.onload = function () {
                AutoUpdater.isChecking = false;
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        AutoUpdater.latestRelease = data;
                        var latestTag = (data.tag_name || '').replace(/^v/i, '').trim();

                        if (AutoUpdater.isNewerVersion(latestTag, CURRENT_VERSION)) {
                            AutoUpdater.showUpdateBadge(data);
                            if (callback) callback(true, data);
                        } else {
                            if (!silent && typeof showToast === 'function') {
                                showToast('âœ…', 'PrConsole is up to date (v' + CURRENT_VERSION + ').');
                            }
                            if (callback) callback(false, null);
                        }
                    } catch (err) {
                        if (!silent) console.warn('[Updater] Parse error:', err);
                        if (callback) callback(false, null);
                    }
                } else {
                    if (!silent) console.warn('[Updater] HTTP status:', xhr.status);
                    if (callback) callback(false, null);
                }
            };

            xhr.onerror = function () {
                AutoUpdater.isChecking = false;
                if (!silent) console.warn('[Updater] Network error checking updates.');
                if (callback) callback(false, null);
            };

            xhr.ontimeout = function () {
                AutoUpdater.isChecking = false;
                if (callback) callback(false, null);
            };

            xhr.send();
        },

        /**
         * Compare semver strings (e.g. 1.1.0 > 1.0.0)
         */
        isNewerVersion: function (latest, current) {
            if (!latest || !current) return false;
            var lParts = latest.split('.').map(function (n) { return parseInt(n, 10) || 0; });
            var cParts = current.split('.').map(function (n) { return parseInt(n, 10) || 0; });

            for (var i = 0; i < Math.max(lParts.length, cParts.length); i++) {
                var l = lParts[i] || 0;
                var c = cParts[i] || 0;
                if (l > c) return true;
                if (l < c) return false;
            }
            return false;
        },

        /**
         * Show non-intrusive update badge/banner in the UI
         */
        showUpdateBadge: function (releaseData) {
            var banner = document.getElementById('updateBanner');
            if (!banner) {
                banner = document.createElement('div');
                banner.id = 'updateBanner';
                banner.className = 'update-banner';
                var header = document.querySelector('.console-header');
                if (header && header.parentNode) {
                    header.parentNode.insertBefore(banner, header.nextSibling);
                }
            }

            var ver = releaseData.tag_name || 'New Version';
            banner.innerHTML =
                '<div class="update-content">' +
                '   <span class="update-icon">ðŸš€</span>' +
                '   <span class="update-text"><strong>Update Available (' + ver + ')</strong></span>' +
                '   <button id="applyUpdateBtn" class="update-btn">Update Now</button>' +
                '   <button id="dismissUpdateBtn" class="update-close-btn">âœ•</button>' +
                '</div>';
            banner.style.display = 'block';

            var applyBtn = document.getElementById('applyUpdateBtn');
            if (applyBtn) {
                applyBtn.addEventListener('click', function () {
                    AutoUpdater.downloadAndInstallUpdate(releaseData);
                });
            }

            var dismissBtn = document.getElementById('dismissUpdateBtn');
            if (dismissBtn) {
                dismissBtn.addEventListener('click', function () {
                    banner.style.display = 'none';
                });
            }
        },

        /**
         * Download update ZIP from GitHub and extract into extension directory
         */
        downloadAndInstallUpdate: function (releaseData) {
            var applyBtn = document.getElementById('applyUpdateBtn');
            if (applyBtn) {
                applyBtn.disabled = true;
                applyBtn.textContent = 'Downloading...';
            }

            if (!window.require) {
                // Fallback: Open GitHub Release page in default browser
                if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
                    window.cep.util.openURLInDefaultBrowser(releaseData.html_url || ('https://github.com/' + GITHUB_REPO + '/releases'));
                } else {
                    window.open(releaseData.html_url || ('https://github.com/' + GITHUB_REPO + '/releases'), '_blank');
                }
                return;
            }

            try {
                var https = window.require('https');
                var fs = window.require('fs');
                var path = window.require('path');
                var child_process = window.require('child_process');
                var os = window.require('os');

                // Determine asset download URL or zipball
                var downloadUrl = releaseData.zipball_url;
                if (releaseData.assets && releaseData.assets.length > 0) {
                    var zipAsset = releaseData.assets.find(function (a) { return a.name && a.name.toLowerCase().endsWith('.zip'); });
                    if (zipAsset && zipAsset.browser_download_url) {
                        downloadUrl = zipAsset.browser_download_url;
                    }
                }

                if (!downloadUrl) {
                    throw new Error("No download URL found in release.");
                }

                var tempZip = path.join(os.tmpdir(), 'PrConsole_Update_' + Date.now() + '.zip');
                var tempExtract = path.join(os.tmpdir(), 'PrConsole_Extracted_' + Date.now());

                var appData = process.env.APPDATA || process.env.USERPROFILE;
                var targetExtDir = path.join(appData, 'Adobe', 'CEP', 'extensions', 'PrConsole');

                var downloadFile = function (url, dest, cb) {
                    var file = fs.createWriteStream(dest);
                    var req = https.get(url, {
                        headers: { 'User-Agent': 'PrConsole-Updater' }
                    }, function (response) {
                        if (response.statusCode === 302 || response.statusCode === 301) {
                            file.close();
                            fs.unlink(dest, function () {});
                            return downloadFile(response.headers.location, dest, cb);
                        }
                        if (response.statusCode !== 200) {
                            file.close();
                            return cb(new Error('Download failed with status: ' + response.statusCode));
                        }
                        response.pipe(file);
                        file.on('finish', function () {
                            file.close(cb);
                        });
                    });
                    req.on('error', function (err) {
                        fs.unlink(dest, function () {});
                        cb(err);
                    });
                };

                downloadFile(downloadUrl, tempZip, function (err) {
                    if (err) {
                        if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Retry'; }
                        alert('Update download failed: ' + err.message);
                        return;
                    }

                    if (applyBtn) applyBtn.textContent = 'Installing...';

                    // Extract via PowerShell
                    var psCmd = 'Expand-Archive -Path "' + tempZip + '" -DestinationPath "' + tempExtract + '" -Force';
                    child_process.exec('powershell -Command "' + psCmd + '"', function (psErr) {
                        try { fs.unlinkSync(tempZip); } catch (e) {}

                        if (psErr) {
                            if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Retry'; }
                            alert('Extraction failed: ' + psErr.message);
                            return;
                        }

                        // Locate source files (might be inside extracted subfolder)
                        var extractedRoot = tempExtract;
                        var items = fs.readdirSync(tempExtract);
                        if (items.length === 1 && fs.statSync(path.join(tempExtract, items[0])).isDirectory()) {
                            extractedRoot = path.join(tempExtract, items[0]);
                        }

                        // Copy updated files to extension directory
                        var copyPsCmd = 'Copy-Item -Path "' + extractedRoot + '\\*" -Destination "' + targetExtDir + '" -Recurse -Force';
                        child_process.exec('powershell -Command "' + copyPsCmd + '"', function (copyErr) {
                            try {
                                child_process.exec('powershell -Command "Remove-Item -Path \'' + tempExtract + '\' -Recurse -Force"');
                            } catch (e) {}

                            if (applyBtn) applyBtn.textContent = 'Done!';

                            // Live Refresh Console
                            setTimeout(function () {
                                window.location.reload();
                            }, 800);
                        });
                    });
                });

            } catch (ex) {
                if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Retry'; }
                alert('Auto-update error: ' + ex.message);
            }
        }
    };

    // Expose globally
    window.AutoUpdater = AutoUpdater;

    // Check silently after 3 seconds of panel load
    setTimeout(function () {
        AutoUpdater.checkForUpdates(true);
    }, 3000);
})();

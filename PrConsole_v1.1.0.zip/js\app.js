/**
 * Main Application Controller for PrFX Console
 * Modern Dark Glassmorphism Edition with Comprehensive FX Database, Preset Scanner & Favorites
 */

(function () {
    'use strict';

    // State Management
    var csInterface = null;
    var searchEngine = null;
    var currentCategory = 'all';
    var activeDb = [];
    var currentResults = [];
    var selectedIndex = 0;
    var quickSlots = [];
    var snapshots = [];
    var favorites = [];
    var isActionExecuting = false;
    var toastTimeout = null;

    // DOM Elements
    var DOM = {};

    function initDOM() {
        DOM.consoleApp = document.getElementById('consoleApp');
        DOM.searchInput = document.getElementById('searchInput');
        DOM.clearSearchBtn = document.getElementById('clearSearchBtn');
        DOM.resultsContainer = document.getElementById('resultsContainer');
        DOM.quickSlotsBar = document.getElementById('quickSlotsBar');
        DOM.categoryTabs = document.getElementById('categoryTabs');
        DOM.hostStatusBadge = document.getElementById('hostStatusBadge');
        DOM.statusDot = document.getElementById('statusDot');
        DOM.hostStatusText = document.getElementById('hostStatusText');
        DOM.toastContainer = document.getElementById('toastContainer');
        DOM.toastMessage = document.getElementById('toastMessage');
        DOM.toastIcon = document.getElementById('toastIcon');

        // Modals
        DOM.galleryModal = document.getElementById('galleryModal');
        DOM.openGalleryBtn = document.getElementById('openGalleryBtn');
        DOM.closeGalleryModalBtn = document.getElementById('closeGalleryModalBtn');
        DOM.galleryGrid = document.getElementById('galleryGrid');

        DOM.settingsModal = document.getElementById('settingsModal');
        DOM.openSettingsBtn = document.getElementById('openSettingsBtn');
        DOM.closeSettingsModalBtn = document.getElementById('closeSettingsModalBtn');
        DOM.settingsSlotsList = document.getElementById('settingsSlotsList');
        DOM.resetSlotsBtn = document.getElementById('resetSlotsBtn');
        DOM.manualReloadBtn = document.getElementById('manualReloadBtn');
        DOM.shortcutsTabBtn = document.getElementById('shortcutsTabBtn');

        // Shortcut Settings
        DOM.shortcutRecorderInput = document.getElementById('shortcutRecorderInput');
        DOM.saveShortcutBtn = document.getElementById('saveShortcutBtn');
        DOM.currentShortcutBadge = document.getElementById('currentShortcutBadge');
        DOM.footerShortcutPill = document.getElementById('footerShortcutPill');

        // Updates
        DOM.checkUpdateBtn = document.getElementById('checkUpdateBtn');
        DOM.updateStatusText = document.getElementById('updateStatusText');
    }

    /**
     * Initialize Application
     */
    function init() {
        try {
            if (typeof CSInterface !== 'undefined') {
                csInterface = new CSInterface();
            }
        } catch (e) {
            console.warn('[PrFX] CSInterface init warning:', e);
        }

        initDOM();
        loadFavorites();

        // 1. Initialize Database with built-in comprehensive catalog immediately!
        if (typeof EFFECTS_DATABASE !== 'undefined' && Array.isArray(EFFECTS_DATABASE)) {
            activeDb = EFFECTS_DATABASE.slice();
        } else {
            activeDb = [];
        }

        // 2. Scan all 3rd-Party MediaCore Plugins (Boris FX, Sapphire, RSMB, Trapcode, Twixtor...)
        scanMediaCorePlugins();

        // 3. Scan all Premiere User Presets from .prfpset files
        scanUserPresetsFromDisk();

        // 4. Initialize Fuzzy Search Engine
        if (typeof FuzzySearchEngine !== 'undefined') {
            searchEngine = new FuzzySearchEngine(activeDb);
        }

        loadQuickSlots();
        loadSnapshots();
        loadGlobalShortcut();

        renderQuickSlots();
        updateResults();

        setupEvents();
        setupShortcutRecorder();
        checkHostStatus();

        // 4. Also scan dynamic QE effect catalog from Premiere
        refreshDynamicEffects();

        // 5. Dynamic Sequence & Host Tracking (Polls smoothly every 1.2s & on focus)
        setInterval(checkHostStatus, 1200);
        window.addEventListener('focus', checkHostStatus);
        window.addEventListener('mouseenter', checkHostStatus);
        if (csInterface) {
            try {
                csInterface.addEventListener('com.adobe.csxs.events.DocumentAfterActivate', checkHostStatus);
                csInterface.addEventListener('com.adobe.csxs.events.SequenceAfterActivate', checkHostStatus);
                csInterface.addEventListener('com.adobe.csxs.events.ApplicationActivate', checkHostStatus);
            } catch (e) {}
        }

        setTimeout(function () {
            if (DOM.searchInput) {
                DOM.searchInput.focus();
                DOM.searchInput.select();
            }
        }, 80);
    }

    /**
     * Load & Save Favorites from localStorage
     */
    function loadFavorites() {
        try {
            var saved = localStorage.getItem('prfx_favorites');
            favorites = saved ? JSON.parse(saved) : [];
        } catch (e) {
            favorites = [];
        }
    }

    function saveFavorites() {
        try {
            localStorage.setItem('prfx_favorites', JSON.stringify(favorites));
        } catch (e) {}
    }

    function toggleFavorite(itemId) {
        var idx = favorites.indexOf(itemId);
        if (idx !== -1) {
            favorites.splice(idx, 1);
            showToast('☆', 'Removed from favorites');
        } else {
            favorites.push(itemId);
            showToast('★', 'Added to favorites');
        }
        saveFavorites();
        updateResults();
    }

    /**
     * Clean plugin file name for friendly search display
     */
    function cleanPluginName(fileName) {
        var name = fileName.replace(/\.[^/.]+$/, '');
        name = name.replace(/_64$/i, '').replace(/_x64$/i, '').replace(/AE$/i, '');
        return name.trim();
    }

    /**
     * Scan all 3rd-Party MediaCore Plugins
     * (Boris FX BCC, Sapphire, RSMB, Trapcode, Twixtor, Pixel Sorter, etc.)
     */
    function scanMediaCorePlugins() {
        if (typeof require === 'undefined') return;

        try {
            var fs = require('fs');
            var path = require('path');

            var mediaCoreDir = 'C:\\Program Files\\Adobe\\Common\\Plug-ins\\7.0\\MediaCore';
            if (!fs.existsSync(mediaCoreDir)) return;

            var seenNames = {};
            activeDb.forEach(function (itm) { seenNames[itm.name.toLowerCase()] = true; });

            function walk(dir, category) {
                try {
                    var items = fs.readdirSync(dir);
                    items.forEach(function (file) {
                        var fullPath = path.join(dir, file);
                        try {
                            var stat = fs.statSync(fullPath);
                            if (stat.isDirectory()) {
                                walk(fullPath, category || file);
                            } else {
                                var ext = path.extname(file).toLowerCase();
                                if (ext === '.aex' || ext === '.prm') {
                                    var pName = cleanPluginName(file);
                                    var key = pName.toLowerCase();
                                    if (pName && !seenNames[key]) {
                                        seenNames[key] = true;
                                        var isTransition = /transition|dissolve|wipe/i.test(pName);
                                        activeDb.push({
                                            id: 'plugin_' + pName.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase(),
                                            name: pName,
                                            matchName: pName,
                                            category: category || 'Plugins',
                                            type: isTransition ? 'transition' : 'video_effect',
                                            icon: isTransition ? 'maximize-2' : 'sparkles',
                                            description: (category ? (category + ' ') : '') + (isTransition ? 'Transition' : 'Plugin Effect'),
                                            keywords: [key, 'plugin', (category || '').toLowerCase()]
                                        });
                                    }
                                }
                            }
                        } catch (err) {}
                    });
                } catch (err) {}
            }

            walk(mediaCoreDir, '');
            console.log('[PrFX] MediaCore plugins scanned. Active DB size:', activeDb.length);
        } catch (err) {
            console.warn('[PrFX] Could not scan MediaCore plugins:', err);
        }
    }

    /**
     * Scan Premiere User Presets (.prfpset) directly from Documents & AppData
     * Uses precise XML object-type mapping to exclude bins/folders and extract all user presets.
     */
    function scanUserPresetsFromDisk() {
        if (typeof require === 'undefined') return;

        try {
            var fs = require('fs');
            var path = require('path');
            var os = require('os');

            var userHome = os.homedir() || process.env.USERPROFILE || 'C:\\Users\\NANO TECH';
            var searchDirs = [
                path.join(userHome, 'Documents', 'Adobe', 'Premiere Pro'),
                path.join(userHome, 'AppData', 'Roaming', 'Adobe', 'Premiere Pro'),
                path.join(userHome, 'OneDrive', 'Documents', 'Adobe', 'Premiere Pro')
            ];

            var seenNames = {};
            activeDb.forEach(function (itm) { seenNames[itm.name.toLowerCase()] = true; });

            function parsePresetFile(filePath) {
                try {
                    if (!fs.existsSync(filePath)) return;
                    var xml = fs.readFileSync(filePath, 'utf8');

                    var objMap = {};
                    var objRegex = /<([a-zA-Z0-9_]+)\s+ObjectID="(\d+)"/g;
                    var m;
                    while ((m = objRegex.exec(xml)) !== null) {
                        objMap[m[2]] = m[1];
                    }

                    var treeRegex = /<TreeItemBase[^>]*>[\s\S]*?<Name>([^<]+)<\/Name>[\s\S]*?<Data\s+ObjectRef="(\d+)"\/>[\s\S]*?<\/TreeItemBase>/gi;
                    while ((m = treeRegex.exec(xml)) !== null) {
                        var pName = m[1].trim();
                        var dataRef = m[2];
                        var objType = objMap[dataRef] || '';

                        // Skip bins / folder items and default root names
                        if (objType.indexOf('Bin') !== -1 || ['root', 'presets', 'effects'].includes(pName.toLowerCase())) {
                            continue;
                        }

                        // Check if it's a real preset, filter, or transition
                        var isRealPreset = (objType.indexOf('Preset') !== -1 || objType.indexOf('Transition') !== -1 || objType.indexOf('Filter') !== -1);
                        if (isRealPreset && pName) {
                            var key = pName.toLowerCase();
                            if (!seenNames[key]) {
                                seenNames[key] = true;
                                var isTransition = (objType.indexOf('Transition') !== -1) || /transition|wipe|dissolve/i.test(pName);
                                var isAudio = /music|sfx|audio|voice|pause|eq|flanger|phaser/i.test(pName);

                                // Extract underlying effect name & matchName from XML chunk
                                var itemIdx = xml.indexOf('ObjectID="' + dataRef + '"');
                                var chunk = itemIdx !== -1 ? xml.slice(itemIdx, itemIdx + 8000) : '';

                                var baseEffect = '';
                                var baseMatchName = '';
                                var dMatch = chunk.match(/<DisplayName>([^<]+)<\/DisplayName>/);
                                var fMatch = chunk.match(/<FilterMatchName>([^<]+)<\/FilterMatchName>/) || chunk.match(/<MatchName>([^<]+)<\/MatchName>/);

                                if (dMatch) baseEffect = dMatch[1].trim();
                                if (fMatch) baseMatchName = fMatch[1].trim();

                                // Semantic fallbacks for common user presets
                                if (!baseEffect) {
                                    if (/zoom|transform|scale/i.test(pName)) {
                                        baseEffect = 'Transform';
                                        baseMatchName = 'AE.ADBE Geometry2';
                                    } else if (/shadow/i.test(pName)) {
                                        baseEffect = 'Drop Shadow';
                                        baseMatchName = 'AE.ADBE Drop Shadow';
                                    } else if (/blur/i.test(pName)) {
                                        baseEffect = 'Gaussian Blur';
                                        baseMatchName = 'AE.ADBE Gaussian Blur 2';
                                    } else if (/lowpass/i.test(pName)) {
                                        baseEffect = 'Lowpass';
                                        baseMatchName = 'Internal Lowpass';
                                        isAudio = true;
                                    } else if (/sfx/i.test(pName)) {
                                        baseEffect = 'Flanger';
                                        isAudio = true;
                                    }
                                }

                                activeDb.push({
                                    id: 'preset_' + pName.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase(),
                                    name: pName,
                                    matchName: pName,
                                    baseEffect: baseEffect || pName,
                                    baseMatchName: baseMatchName || baseEffect || pName,
                                    isAudio: isAudio,
                                    category: 'User Presets',
                                    type: isTransition ? 'transition' : 'preset',
                                    icon: isTransition ? 'maximize-2' : (isAudio ? 'music' : 'sparkles'),
                                    description: (baseEffect ? ('Preset based on ' + baseEffect) : 'User Effect Preset'),
                                    keywords: [key, 'preset', 'user', 'custom', (baseEffect || '').toLowerCase()]
                                });
                            }
                        }
                    }
                } catch (e) {
                    console.warn('[PrFX] Error reading preset file:', filePath, e);
                }
            }

            function findPrfpsetFiles(dir, depth) {
                if (depth > 4) return;
                try {
                    if (!fs.existsSync(dir)) return;
                    var entries = fs.readdirSync(dir);
                    entries.forEach(function (entry) {
                        var fullPath = path.join(dir, entry);
                        try {
                            var stat = fs.statSync(fullPath);
                            if (stat.isDirectory()) {
                                findPrfpsetFiles(fullPath, depth + 1);
                            } else if (entry.toLowerCase().endsWith('.prfpset')) {
                                parsePresetFile(fullPath);
                            }
                        } catch (err) {}
                    });
                } catch (err) {}
            }

            searchDirs.forEach(function (baseDir) {
                findPrfpsetFiles(baseDir, 0);
            });

            console.log('[PrFX] User presets loaded. Total library items:', activeDb.length);
        } catch (err) {
            console.warn('[PrFX] Could not scan user presets:', err);
        }
    }

    /**
     * Dynamically fetch additional effects from Premiere Pro QE if available
     */
    function refreshDynamicEffects() {
        if (!csInterface || !window.__adobe_cep__) return;

        csInterface.evalScript('PrFX_Host.getAllEffects()', function (resStr) {
            try {
                var res = JSON.parse(resStr);
                if (res.success && res.list && res.list.length > 0) {
                    var seenMap = {};
                    activeDb.forEach(function (itm) { seenMap[itm.name.toLowerCase()] = true; });

                    res.list.forEach(function (newItem) {
                        if (newItem.name && !seenMap[newItem.name.toLowerCase()]) {
                            seenMap[newItem.name.toLowerCase()] = true;
                            activeDb.push({
                                id: newItem.id || ('custom_' + newItem.name.toLowerCase().replace(/[^a-z0-9]/g, '_')),
                                name: newItem.name,
                                matchName: newItem.matchName || newItem.name,
                                category: newItem.category || 'Effects',
                                type: newItem.type || 'video_effect',
                                icon: newItem.type === 'preset' ? 'sparkles' : (newItem.type.indexOf('audio') !== -1 ? 'palette' : 'droplet'),
                                description: (newItem.category || 'Premiere') + ' Effect',
                                keywords: [newItem.name.toLowerCase()]
                            });
                        }
                    });

                    if (searchEngine) {
                        searchEngine.setDatabase(activeDb);
                    }
                    updateResults();
                }
            } catch (e) {}
        });
    }

    /**
     * Default Quick Slots
     */
    var DEFAULT_QUICK_SLOTS = [
        { slot: "1", id: "lumetri_color", label: "Lumetri" },
        { slot: "2", id: "gaussian_blur", label: "Blur" },
        { slot: "3", id: "crop", label: "Crop" },
        { slot: "4", id: "warp_stabilizer", label: "Warp Stb" },
        { slot: "5", id: "parametric_eq", label: "EQ" },
        { slot: "6", id: "denoise", label: "DeNoise" },
        { slot: "7", id: "label_mango", label: "Mango" },
        { slot: "8", id: "label_cerulean", label: "Blue" },
        { slot: "9", id: "label_rose", label: "Rose" }
    ];

    function loadQuickSlots() {
        var saved = localStorage.getItem('prfx_quick_slots');
        if (saved) {
            try {
                quickSlots = JSON.parse(saved);
            } catch (e) {
                quickSlots = DEFAULT_QUICK_SLOTS.slice();
            }
        } else {
            quickSlots = DEFAULT_QUICK_SLOTS.slice();
        }
    }

    function saveQuickSlots() {
        localStorage.setItem('prfx_quick_slots', JSON.stringify(quickSlots));
        renderQuickSlots();
    }

    function renderQuickSlots() {
        if (!DOM.quickSlotsBar) return;
        DOM.quickSlotsBar.innerHTML = '';
        quickSlots.forEach(function (slot) {
            var btn = document.createElement('button');
            btn.className = 'slot-btn';
            btn.innerHTML = '<span class="slot-number">' + slot.slot + '</span><span>' + escapeHtml(slot.label) + '</span>';
            btn.title = "Click or press '" + slot.slot + "' to apply";
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                executeQuickSlot(slot.slot);
            });
            DOM.quickSlotsBar.appendChild(btn);
        });
    }

    function executeQuickSlot(key) {
        var slot = quickSlots.find(function (s) { return s.slot === String(key); });
        if (!slot) return;

        var targetItem = activeDb.find(function (item) { return item.id === slot.id; });
        if (targetItem) {
            executeItem(targetItem);
        } else {
            showToast('⚠️', 'Slot ' + key + ' (' + slot.label + ') not found in catalog.');
        }
    }

    /**
     * Setup Event Listeners
     */
    function setupEvents() {
        // Search Input
        if (DOM.searchInput) {
            DOM.searchInput.addEventListener('input', function () {
                if (DOM.clearSearchBtn) {
                    DOM.clearSearchBtn.style.display = DOM.searchInput.value.length > 0 ? 'inline-flex' : 'none';
                }
                selectedIndex = 0;
                updateResults();
            });
        }

        // Clear Search Button
        if (DOM.clearSearchBtn) {
            DOM.clearSearchBtn.addEventListener('click', function () {
                if (DOM.searchInput) {
                    DOM.searchInput.value = '';
                    DOM.searchInput.focus();
                }
                DOM.clearSearchBtn.style.display = 'none';
                selectedIndex = 0;
                updateResults();
            });
        }

        // Category Tabs
        if (DOM.categoryTabs) {
            DOM.categoryTabs.addEventListener('click', function (e) {
                var btn = e.target.closest('.tab-btn');
                if (!btn) return;

                if (btn.id === 'shortcutsTabBtn') {
                    renderSettingsSlots();
                    openModal(DOM.settingsModal);
                    return;
                }

                document.querySelectorAll('.tab-btn').forEach(function (b) {
                    if (b.id !== 'shortcutsTabBtn') b.classList.remove('active');
                });
                btn.classList.add('active');
                currentCategory = btn.getAttribute('data-filter') || 'all';
                selectedIndex = 0;
                updateResults();
            });
        }

        // Global Keydown Handler
        window.addEventListener('keydown', handleGlobalKeydown);

        // Modals Toggle
        if (DOM.openGalleryBtn) DOM.openGalleryBtn.addEventListener('click', function () { openModal(DOM.galleryModal); });
        if (DOM.closeGalleryModalBtn) DOM.closeGalleryModalBtn.addEventListener('click', function () { closeModal(DOM.galleryModal); });

        if (DOM.openSettingsBtn) {
            DOM.openSettingsBtn.addEventListener('click', function () {
                renderSettingsSlots();
                openModal(DOM.settingsModal);
            });
        }
        if (DOM.closeSettingsModalBtn) DOM.closeSettingsModalBtn.addEventListener('click', function () { closeModal(DOM.settingsModal); });

        if (DOM.resetSlotsBtn) {
            DOM.resetSlotsBtn.addEventListener('click', function () {
                quickSlots = DEFAULT_QUICK_SLOTS.slice();
                saveQuickSlots();
                renderSettingsSlots();
                showToast('🔄', 'Quick slots reset to defaults.');
            });
        }

        // Check for Updates Button
        if (DOM.checkUpdateBtn) {
            DOM.checkUpdateBtn.addEventListener('click', function () {
                if (window.AutoUpdater) {
                    DOM.checkUpdateBtn.disabled = true;
                    DOM.checkUpdateBtn.textContent = 'Checking...';
                    window.AutoUpdater.checkForUpdates(false, function (hasUpdate, releaseData) {
                        DOM.checkUpdateBtn.disabled = false;
                        DOM.checkUpdateBtn.textContent = 'Check for Updates';
                        if (hasUpdate && DOM.updateStatusText) {
                            DOM.updateStatusText.textContent = 'New: ' + (releaseData.tag_name || '');
                            DOM.updateStatusText.style.color = '#e4b94b';
                        }
                    });
                }
            });
        }

        // Overlay Click Close
        [DOM.galleryModal, DOM.settingsModal].forEach(function (modal) {
            if (modal) {
                modal.addEventListener('click', function (e) {
                    if (e.target === modal) closeModal(modal);
                });
            }
        });
    }

    /**
     * Keyboard Navigation & Execution
     */
    function handleGlobalKeydown(e) {
        // Escape Handler: Smoothly closes modals or clears search and returns focus to Premiere timeline
        if (e.key === 'Escape' || e.keyCode === 27) {
            e.preventDefault();

            // 1. Close open modal if active
            if (DOM.galleryModal && DOM.galleryModal.classList.contains('active')) {
                closeModal(DOM.galleryModal);
                if (DOM.searchInput) DOM.searchInput.focus();
                return;
            }
            if (DOM.settingsModal && DOM.settingsModal.classList.contains('active')) {
                closeModal(DOM.settingsModal);
                if (DOM.searchInput) DOM.searchInput.focus();
                return;
            }

            // 2. Clear search input if query exists
            if (DOM.searchInput && DOM.searchInput.value.length > 0) {
                DOM.searchInput.value = '';
                if (DOM.clearSearchBtn) DOM.clearSearchBtn.style.display = 'none';
                selectedIndex = 0;
                updateResults();
                return;
            }

            // 3. Release keyboard focus smoothly back to timeline without closing/destroying panel
            if (DOM.searchInput) {
                DOM.searchInput.blur();
            }
            if (document.activeElement) {
                document.activeElement.blur();
            }
            return;
        }

        // Quick Slots 1-9
        if (['1', '2', '3', '4', '5', '6', '7', '8', '9'].indexOf(e.key) !== -1) {
            if (!DOM.searchInput || DOM.searchInput.value.trim() === '' || e.altKey || e.ctrlKey) {
                e.preventDefault();
                executeQuickSlot(e.key);
                return;
            }
        }

        // Navigation
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (currentResults.length > 0) {
                selectedIndex = (selectedIndex + 1) % currentResults.length;
                renderResultsList();
                scrollSelectedIntoView();
            }
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (currentResults.length > 0) {
                selectedIndex = (selectedIndex - 1 + currentResults.length) % currentResults.length;
                renderResultsList();
                scrollSelectedIntoView();
            }
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (currentResults.length > 0 && currentResults[selectedIndex]) {
                executeItem(currentResults[selectedIndex]);
            }
        } else if (e.key === 'Escape') {
            if (DOM.searchInput && DOM.searchInput.value !== '') {
                DOM.searchInput.value = '';
                if (DOM.clearSearchBtn) DOM.clearSearchBtn.style.display = 'none';
                selectedIndex = 0;
                updateResults();
            } else if (csInterface) {
                csInterface.closeExtension();
            }
        }
    }

    /**
     * Update Results based on Search, Category Filter & Favorite Sorting
     */
    function updateResults() {
        var query = DOM.searchInput ? DOM.searchInput.value.trim() : '';
        var rawResults = [];

        if (searchEngine && query.length > 0) {
            rawResults = searchEngine.search(query, currentCategory, 60);
        } else {
            var qLower = query.toLowerCase();
            rawResults = activeDb.filter(function (item) {
                if (currentCategory !== 'all') {
                    if (currentCategory === 'video' && item.type !== 'video_effect' && item.type !== 'transition' && item.type !== 'video_transition') return false;
                    if (currentCategory === 'audio' && item.type !== 'audio_effect' && item.type !== 'audio_transition') return false;
                    if (currentCategory === 'preset' && item.type !== 'preset') return false;
                }
                if (!qLower) return true;
                return (item.name && item.name.toLowerCase().indexOf(qLower) !== -1) ||
                       (item.matchName && item.matchName.toLowerCase().indexOf(qLower) !== -1) ||
                       (item.category && item.category.toLowerCase().indexOf(qLower) !== -1);
            });
        }

        // Sort: Favorites ALWAYS at the TOP!
        rawResults.sort(function (a, b) {
            var aFav = favorites.indexOf(a.id) !== -1 ? 1 : 0;
            var bFav = favorites.indexOf(b.id) !== -1 ? 1 : 0;
            if (aFav !== bFav) return bFav - aFav;
            return 0;
        });

        currentResults = rawResults.slice(0, 60);

        if (selectedIndex >= currentResults.length) {
            selectedIndex = 0;
        }

        renderResultsList();
    }

    /**
     * Render Results Cards with Favorite Star
     */
    function renderResultsList() {
        if (!DOM.resultsContainer) return;

        if (currentResults.length === 0) {
            DOM.resultsContainer.innerHTML =
                '<div class="empty-state">' +
                '<p style="font-size: 13px; font-weight: 500;">No matching effects or commands found.</p>' +
                '</div>';
            return;
        }

        DOM.resultsContainer.innerHTML = '';

        currentResults.forEach(function (item, index) {
            var isSelected = index === selectedIndex;
            var isFav = favorites.indexOf(item.id) !== -1;
            var el = document.createElement('div');
            el.className = 'result-item type-' + item.type + (isSelected ? ' selected' : '');

            var badgeText = item.category || item.type.replace('_', ' ');
            var iconSvg = getIconSvg(item.icon);

            var starSvg = isFav
                ? '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>'
                : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';

            el.innerHTML =
                '<div class="item-icon-box">' + iconSvg + '</div>' +
                '<div class="item-content">' +
                '<div class="item-title-row">' +
                '<span class="item-name">' + escapeHtml(item.name) + '</span>' +
                '<span class="item-badge">' + escapeHtml(badgeText) + '</span>' +
                '</div>' +
                '<div class="item-description">' + escapeHtml(item.description || '') + '</div>' +
                '</div>' +
                '<button class="favorite-btn ' + (isFav ? 'active' : '') + '" title="' + (isFav ? 'Remove from favorites' : 'Add to favorites') + '">' +
                starSvg +
                '</button>' +
                '<span class="item-action-hint">APPLY</span>';

            // Favorite button click
            var starBtn = el.querySelector('.favorite-btn');
            if (starBtn) {
                starBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    toggleFavorite(item.id);
                });
            }

            // Mouse hover selection
            el.addEventListener('mouseenter', function () {
                selectedIndex = index;
                var allItems = DOM.resultsContainer.querySelectorAll('.result-item');
                allItems.forEach(function (itm, i) {
                    if (i === index) itm.classList.add('selected');
                    else itm.classList.remove('selected');
                });
            });

            // Single Click -> APPLY!
            el.addEventListener('click', function (ev) {
                ev.stopPropagation();
                selectedIndex = index;
                executeItem(item);
            });

            DOM.resultsContainer.appendChild(el);
        });
    }

    function scrollSelectedIntoView() {
        var selectedEl = DOM.resultsContainer.querySelector('.result-item.selected');
        if (selectedEl) {
            selectedEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        }
    }

    /**
     * Execute selected effect, transition, or command
     */
    function executeItem(item) {
        if (!item || isActionExecuting) return;
        isActionExecuting = true;
        setTimeout(function () { isActionExecuting = false; }, 400);

        showToast('⏳', 'Applying "' + item.name + '"...');

        if (!csInterface || !window.__adobe_cep__) {
            setTimeout(function () {
                if (item.id === 'cmd_take_snapshot') {
                    handleSnapshotMock();
                } else {
                    showToast('✅', '[Preview Mode] Applied "' + item.name + '"');
                }
            }, 120);
            return;
        }

        // ExtendScript Explicit Dispatch
        if (item.type === 'video_effect') {
            var safeName = item.name.replace(/"/g, '\\"');
            var safeMatch = (item.matchName || item.name).replace(/"/g, '\\"');
            var script = 'PrFX_Host.applyVideoEffect("' + safeName + '", "' + safeMatch + '")';
            csInterface.evalScript(script, function (result) {
                handleScriptResponse(result, item.name);
            });
        } else if (item.type === 'audio_effect') {
            var safeNameA = item.name.replace(/"/g, '\\"');
            var safeMatchA = (item.matchName || item.name).replace(/"/g, '\\"');
            var scriptA = 'PrFX_Host.applyAudioEffect("' + safeNameA + '", "' + safeMatchA + '")';
            csInterface.evalScript(scriptA, function (result) {
                handleScriptResponse(result, item.name);
            });
        } else if (item.type === 'preset') {
            var safeNameP = item.name.replace(/"/g, '\\"');
            var safeBase = (item.baseEffect || item.name).replace(/"/g, '\\"');
            var safeBaseMatch = (item.baseMatchName || item.matchName || item.name).replace(/"/g, '\\"');
            var scriptP = 'PrFX_Host.applyPreset("' + safeNameP + '", "' + safeBase + '", "' + safeBaseMatch + '", ' + (item.isAudio ? 'true' : 'false') + ')';
            csInterface.evalScript(scriptP, function (result) {
                handleScriptResponse(result, item.name);
            });
        } else if (item.type === 'video_transition' || item.type === 'audio_transition' || item.type === 'transition') {
            var safeName2 = item.name.replace(/"/g, '\\"');
            var script2 = 'PrFX_Host.applyTransition("' + safeName2 + '")';
            csInterface.evalScript(script2, function (result) {
                handleScriptResponse(result, item.name);
            });
        } else if (item.type === 'command') {
            if (item.id === 'cmd_take_snapshot') {
                takeSnapshot();
            } else {
                var cmdVal = item.commandId || item.matchName || item.id;
                var script3 = 'PrFX_Host.executeCommand("' + cmdVal + '")';
                csInterface.evalScript(script3, function (result) {
                    handleScriptResponse(result, item.name);
                });
            }
        } else if (item.type === 'label') {
            var script4 = 'PrFX_Host.setClipLabel(' + item.labelIndex + ')';
            csInterface.evalScript(script4, function (result) {
                handleScriptResponse(result, item.name);
            });
        }
    }

    /**
     * Handle ExtendScript Response JSON
     */
    function handleScriptResponse(responseStr, actionName) {
        try {
            var res = JSON.parse(responseStr);
            if (res.success) {
                showToast('✅', res.message || ('Applied ' + actionName));
            } else {
                showToast('⚠️', res.message || res.error || ('Could not apply ' + actionName));
            }
        } catch (e) {
            showToast('ℹ️', responseStr || ('Action: ' + actionName));
        }
    }

    /**
     * Take High-Res Snapshot Frame
     */
    function takeSnapshot() {
        if (!csInterface) return;

        showToast('📷', 'Capturing snapshot frame...');
        var script = 'PrFX_Host.captureSnapshot("")';

        csInterface.evalScript(script, function (result) {
            try {
                var res = JSON.parse(result);
                if (res.success) {
                    addSnapshot({
                        id: Date.now(),
                        path: res.filePath,
                        timecode: res.timecode || '00:00:00:00',
                        date: new Date().toLocaleTimeString()
                    });
                    showToast('📸', 'Snapshot saved (' + res.timecode + ')');
                } else {
                    showToast('⚠️', res.message || 'Snapshot capture failed.');
                }
            } catch (e) {
                showToast('⚠️', 'Snapshot error.');
            }
        });
    }

    function handleSnapshotMock() {
        var mockSnap = {
            id: Date.now(),
            path: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&auto=format&fit=crop&q=60',
            timecode: '00:01:24:12',
            date: new Date().toLocaleTimeString()
        };
        addSnapshot(mockSnap);
        showToast('📸', 'Snapshot captured (Demo Mode)!');
    }

    /**
     * Snapshot Gallery Storage
     */
    function loadSnapshots() {
        var saved = localStorage.getItem('prfx_snapshots');
        if (saved) {
            try {
                snapshots = JSON.parse(saved);
            } catch (e) {
                snapshots = [];
            }
        }
        renderGalleryGrid();
    }

    function addSnapshot(snap) {
        snapshots.unshift(snap);
        if (snapshots.length > 30) snapshots.pop();
        localStorage.setItem('prfx_snapshots', JSON.stringify(snapshots));
        renderGalleryGrid();
    }

    function renderGalleryGrid() {
        if (!DOM.galleryGrid) return;
        if (snapshots.length === 0) {
            DOM.galleryGrid.innerHTML =
                '<div style="grid-column: 1/-1; text-align: center; padding: 30px; color: var(--text-muted);">' +
                '<p>No snapshots captured yet.</p>' +
                '<p style="font-size: 11px; margin-top: 4px;">Use slot 9 to capture current frame.</p>' +
                '</div>';
            return;
        }

        DOM.galleryGrid.innerHTML = '';
        snapshots.forEach(function (snap) {
            var item = document.createElement('div');
            item.style.cssText = 'position: relative; border-radius: var(--radius-sm); overflow: hidden; border: 1px solid var(--border-subtle); aspect-ratio: 16/9; background: #000; cursor: pointer;';
            item.innerHTML =
                '<img src="' + snap.path + '" alt="Snapshot" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=\'https://via.placeholder.com/320x180/1a1a24/ffffff?text=Snapshot\'">' +
                '<div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.7); padding: 2px 6px; display: flex; justify-content: space-between; font-size: 9.5px; color: #fff;">' +
                '<span>' + snap.timecode + '</span>' +
                '<span>' + snap.date + '</span>' +
                '</div>';
            item.addEventListener('click', function () {
                showToast('🔍', 'Snapshot: ' + snap.timecode);
            });
            DOM.galleryGrid.appendChild(item);
        });
    }

    /**
     * Settings Slots Editor
     */
    function renderSettingsSlots() {
        if (!DOM.settingsSlotsList) return;
        DOM.settingsSlotsList.innerHTML = '';

        quickSlots.forEach(function (slot, idx) {
            var row = document.createElement('div');
            row.style.cssText = 'display: flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.04); padding: 6px 10px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);';

            var optionsHtml = '';
            activeDb.forEach(function (dbItem) {
                var sel = dbItem.id === slot.id ? ' selected' : '';
                optionsHtml += '<option value="' + dbItem.id + '"' + sel + '>' + escapeHtml(dbItem.name) + ' (' + escapeHtml(dbItem.category) + ')</option>';
            });

            row.innerHTML =
                '<span class="slot-number">' + slot.slot + '</span>' +
                '<span style="font-size: 12px; font-weight: 600; min-width: 90px; color: var(--text-primary);">' + escapeHtml(slot.label) + '</span>' +
                '<select data-slot-idx="' + idx + '" style="flex: 1; background: var(--bg-surface-elevated); color: var(--text-primary); border: 1px solid var(--border-subtle); padding: 4px 6px; border-radius: var(--radius-sm); font-size: 11.5px; outline: none;">' +
                optionsHtml +
                '</select>';

            var select = row.querySelector('select');
            select.addEventListener('change', (function (slotIdx, slotObj) {
                return function (ev) {
                    var newId = ev.target.value;
                    var found = activeDb.find(function (dbItem) { return dbItem.id === newId; });
                    if (found) {
                        quickSlots[slotIdx].id = found.id;
                        quickSlots[slotIdx].label = found.name.length > 12 ? found.name.substring(0, 10) + '..' : found.name;
                        saveQuickSlots();
                        showToast('💾', 'Slot ' + slotObj.slot + ' set to: ' + found.name);
                    }
                };
            })(idx, slot));

            DOM.settingsSlotsList.appendChild(row);
        });
    }

    /**
     * Check Premiere Host Status
     */
    function checkHostStatus() {
        if (csInterface && window.__adobe_cep__) {
            csInterface.evalScript('PrFX_Host.checkStatus()', function (resStr) {
                try {
                    var res = JSON.parse(resStr);
                    if (res.success) {
                        if (DOM.statusDot) DOM.statusDot.classList.remove('disconnected');
                        if (DOM.hostStatusText) DOM.hostStatusText.textContent = res.sequenceName || 'Connected';
                        if (DOM.hostStatusBadge) DOM.hostStatusBadge.title = 'Active Sequence: ' + res.sequenceName;
                    } else {
                        if (DOM.statusDot) DOM.statusDot.classList.add('disconnected');
                        if (DOM.hostStatusText) DOM.hostStatusText.textContent = 'No Sequence';
                    }
                } catch (e) {
                    if (DOM.statusDot) DOM.statusDot.classList.remove('disconnected');
                    if (DOM.hostStatusText) DOM.hostStatusText.textContent = 'Ready';
                }
            });
        } else {
            if (DOM.statusDot) DOM.statusDot.classList.remove('disconnected');
            if (DOM.hostStatusText) DOM.hostStatusText.textContent = 'Browser Test';
        }
    }

    /**
     * Modal Helpers
     */
    function openModal(modal) {
        if (modal) modal.classList.add('active');
    }

    function closeModal(modal) {
        if (modal) modal.classList.remove('active');
    }

    /**
     * Dynamic Global Hotkey Management
     */
    var currentRecordedShortcut = null;

    function loadGlobalShortcut() {
        var shortcutText = "Ctrl + Space";
        try {
            if (window.require) {
                var fs = window.require('fs');
                var path = window.require('path');
                var appData = process.env.APPDATA || process.env.USERPROFILE;
                var configPath = path.join(appData, 'PrFXConsole', 'config.json');
                if (fs.existsSync(configPath)) {
                    var cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                    if (cfg && cfg.shortcut) {
                        shortcutText = cfg.shortcut;
                    }
                }
            } else {
                var saved = localStorage.getItem('prfx_shortcut');
                if (saved) {
                    var parsed = JSON.parse(saved);
                    shortcutText = parsed.shortcut || "Ctrl + Space";
                }
            }
        } catch (e) {}

        if (DOM.currentShortcutBadge) DOM.currentShortcutBadge.textContent = shortcutText;
        if (DOM.footerShortcutPill) DOM.footerShortcutPill.textContent = shortcutText;
    }

    function setupShortcutRecorder() {
        if (!DOM.shortcutRecorderInput || !DOM.saveShortcutBtn) return;

        DOM.shortcutRecorderInput.addEventListener('focus', function () {
            DOM.shortcutRecorderInput.value = 'Press shortcut keys on keyboard...';
            DOM.shortcutRecorderInput.style.borderColor = 'var(--accent-cyan)';
        });

        DOM.shortcutRecorderInput.addEventListener('keydown', function (e) {
            e.preventDefault();
            e.stopPropagation();

            // Ignore standalone modifiers
            if (['Control', 'Shift', 'Alt', 'Meta'].indexOf(e.key) !== -1) {
                return;
            }

            var modifiers = [];
            var fsMod = 0;
            if (e.ctrlKey) { modifiers.push('Ctrl'); fsMod |= 2; }
            if (e.altKey) { modifiers.push('Alt'); fsMod |= 1; }
            if (e.shiftKey) { modifiers.push('Shift'); fsMod |= 4; }
            if (e.metaKey) { modifiers.push('Win'); fsMod |= 8; }

            var keyName = e.key;
            var vk = e.keyCode || 32;

            if (e.code === 'Space' || vk === 32) { keyName = 'Space'; vk = 32; }
            else if (keyName.length === 1) { keyName = keyName.toUpperCase(); }

            var shortcutStr = (modifiers.length > 0 ? modifiers.join(' + ') + ' + ' : '') + keyName;

            currentRecordedShortcut = {
                shortcut: shortcutStr,
                modifiers: modifiers,
                key: keyName,
                vkCode: vk,
                fsModifiers: fsMod
            };

            DOM.shortcutRecorderInput.value = shortcutStr;
            DOM.shortcutRecorderInput.style.borderColor = 'var(--accent-green)';
        });

        DOM.saveShortcutBtn.addEventListener('click', function () {
            if (!currentRecordedShortcut) {
                showToast('⚠️', 'Please press a key combination first.');
                return;
            }

            try {
                if (window.require) {
                    var fs = window.require('fs');
                    var path = window.require('path');
                    var appData = process.env.APPDATA || process.env.USERPROFILE;
                    var dir = path.join(appData, 'PrFXConsole');
                    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
                    var configPath = path.join(dir, 'config.json');
                    fs.writeFileSync(configPath, JSON.stringify(currentRecordedShortcut, null, 2), 'utf8');
                }
            } catch (err) {
                console.warn('Could not write config.json via Node:', err);
            }

            localStorage.setItem('prfx_shortcut', JSON.stringify(currentRecordedShortcut));

            if (DOM.currentShortcutBadge) DOM.currentShortcutBadge.textContent = currentRecordedShortcut.shortcut;
            if (DOM.footerShortcutPill) DOM.footerShortcutPill.textContent = currentRecordedShortcut.shortcut;

            showToast('✅', 'Activation hotkey set to ' + currentRecordedShortcut.shortcut);
            DOM.shortcutRecorderInput.value = '';
            DOM.shortcutRecorderInput.style.borderColor = '';
        });
    }

    /**
     * Toast Feedback
     */
    function showToast(icon, message) {
        if (toastTimeout) clearTimeout(toastTimeout);
        if (DOM.toastIcon) DOM.toastIcon.textContent = icon;
        if (DOM.toastMessage) DOM.toastMessage.textContent = message;
        if (DOM.toastContainer) {
            DOM.toastContainer.classList.add('visible', 'show');
            toastTimeout = setTimeout(function () {
                DOM.toastContainer.classList.remove('visible', 'show');
            }, 2500);
        }
    }

    /**
     * SVG Icons Helper
     */
    function getIconSvg(iconName) {
        var icons = {
            palette: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="13.5" cy="6.5" r=".5"></circle><circle cx="17.5" cy="10.5" r=".5"></circle><circle cx="8.5" cy="7.5" r=".5"></circle><circle cx="6.5" cy="12.5" r=".5"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path></svg>',
            droplet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>',
            crop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6.13 1L6 16a2 2 0 0 0 2 2h15"></path><path d="M1 6.13L16 6a2 2 0 0 1 2 2v15"></path></svg>',
            shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
            move: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="5 9 2 12 5 15"></polyline><polyline points="9 5 12 2 15 5"></polyline><polyline points="15 19 12 22 9 19"></polyline><polyline points="19 9 22 12 19 15"></polyline><line x1="2" y1="12" x2="22" y2="12"></line><line x1="12" y1="2" x2="12" y2="22"></line></svg>',
            sparkles: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l1.912 5.885L20 10.8l-4.5 4.385L16.568 21 12 17.27 7.432 21l1.068-5.815L4 10.8l6.088-1.915L12 3z"></path></svg>',
            scissors: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><line x1="20" y1="4" x2="8.12" y2="15.88"></line><line x1="14.47" y1="14.48" x2="20" y2="20"></line><line x1="8.12" y1="8.12" x2="12" y2="12"></line></svg>',
            trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>',
            camera: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>',
            tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>',
            sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>',
            moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>',
            wind: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"></path></svg>',
            zap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
            eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
            activity: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
            grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>',
            film: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line><line x1="2" y1="7" x2="7" y2="7"></line><line x1="2" y1="17" x2="7" y2="17"></line><line x1="17" y1="17" x2="22" y2="17"></line><line x1="17" y1="7" x2="22" y2="7"></line></svg>',
            clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
            music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>',
            sliders: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="21" x2="4" y2="14"></line><line x1="4" y1="10" x2="4" y2="3"></line><line x1="12" y1="21" x2="12" y2="12"></line><line x1="12" y1="8" x2="12" y2="3"></line><line x1="20" y1="21" x2="20" y2="16"></line><line x1="20" y1="12" x2="20" y2="3"></line><line x1="1" y1="14" x2="7" y2="14"></line><line x1="9" y1="8" x2="15" y2="8"></line><line x1="17" y1="16" x2="23" y2="16"></line></svg>',
            layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>',
            'maximize-2': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>',
            'minimize-2': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 14 10 14 10 20"></polyline><polyline points="20 10 14 10 14 4"></polyline><line x1="14" y1="10" x2="21" y2="3"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>',
            'volume-2': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>',
            'volume-1': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>',
            'volume-x': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>',
            'mic-off': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="1" y1="1" x2="23" y2="23"></line><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"></path><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>',
            mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>',
            'alert-triangle': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
            'bar-chart-2': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>',
            'rotate-cw': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>',
            'refresh-cw': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
            'zoom-in': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>',
            'arrow-right': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
            'arrow-up-right': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>',
            'trending-down': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>'
        };

        return icons[iconName] || icons.palette;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();